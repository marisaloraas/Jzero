/*
* @filename lab1_2.c
* @author Marisa Loraas
* @Date 1/26/22
*/
#include <stdio.h>

FILE *yyin;
int yylex();

int main(int argc, char *argv[])
{
   FILE *fp;
   void filecopy(FILE *, FILE *);

   if (argc == 1){
	 		printf("look at me");
      filecopy(stdin, stdout);
		}
   else
      while (--argc > 0)
         if ((fp = fopen(*++argv, "r")) == NULL) {
            printf("cat: can't open %s\n", *argv);
            return 1;
            }
         else {
            filecopy(fp, stdout);
            fclose(fp);
            }
   return 0;
}

void filecopy(FILE *ifp, FILE *ofp)
{
	yyin = ifp;
	int c;
   while ((c = yylex()) != EOF)
      putc(c, ofp);
}

int yylex(){
		return fgetc(yyin);
}
