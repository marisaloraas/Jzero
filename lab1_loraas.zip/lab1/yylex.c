/*
* @filename yylex.c
* @author Marisa Loraas
* @Date 1/26/22
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
FILE *yyin;
int checkchar(int i);
/*
int yylex(){
	return fgetc(yyin);
}
*/
int yylex(){
	int c = fgetc(yyin);
	int temp;
	int flag = 1;
	while(flag != 0){
		//printf("%c\n", c);
		temp = fgetc(yyin);
		if(checkchar(c) == checkchar(temp)){
			c = temp;
			}else{
			//printf("chars do not match\n");
			fseek(yyin, -1, SEEK_CUR);
			flag = 0;
		}
	}
	return checkchar(c);
}

int checkchar(int i){
	if(isspace(i)){
		return 5;
	}else if(isdigit(i)){
		return 3;
	}else if(isalpha(i)){
		if(toupper(i) == 'A' || toupper(i) == 'E' || toupper(i) == 'I' || toupper(i) == 'O'
			|| toupper(i) == 'U'){
				return 1;
			}else{
				return 2;
			}
	}else if(i == EOF){
		//this is the only thing i could do to not have the loop running infinitely
		exit(0);
		return -1;
	}else{
		return 4;
	}
}
