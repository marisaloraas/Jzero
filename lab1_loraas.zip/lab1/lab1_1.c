/*
* @filename lab1_1.c
* @author Marisa Loraas
* @Date 1/26/22
*/
#include <stdio.h>

int main(void){
		FILE *f = fopen("test.txt", "r");
		//FILE *f = fopen("foo.baz", "r");
		if(f == NULL){
			printf("foo.baz not found. \n");
			fclose(f);
			return 1;
		}else{
	  	int i = fgetc(f);
	  	if (i == EOF){
				printf("file is empty. \n");
			}else{
				while(i != EOF){
					printf("%c", i);
					i = fgetc(f);
				}
			fclose(f);
		}
	}
	return 0;
}
