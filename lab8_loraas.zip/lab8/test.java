public class foo {
	int abc, xyz;
   public static int foo(int x, String y) {
	   for(i = 10; i < 20; i++){
		   y++;
	   }
      return x;
     }

   public static int main(String[] args)
  {
   int z;
   a++;
   z = foo(5, "funf");
   return 0;
   }
}
