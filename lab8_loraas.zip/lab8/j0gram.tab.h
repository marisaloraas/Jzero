/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BAD_TOKEN = 258,
     DOUBLE = 259,
     ELSE = 260,
     FOR = 261,
     IF = 262,
     INT = 263,
     RETURN = 264,
     VOID = 265,
     WHILE = 266,
     CHAR = 267,
     FLOAT = 268,
     LONG = 269,
     IDENTIFIER = 270,
     CLASSNAME = 271,
     CLASS = 272,
     STRING = 273,
     BOOL = 274,
     INTLIT = 275,
     DOUBLELIT = 276,
     STRINGLIT = 277,
     BOOLLIT = 278,
     NULLVAL = 279,
     LESSTHANOREQUAL = 280,
     GREATERTHANOREQUAL = 281,
     ISEQUALTO = 282,
     NOTEQUALTO = 283,
     LOGICALAND = 284,
     LOGICALOR = 285,
     LOGICNOT = 286,
     GREATERTHAN = 287,
     LESSTHAN = 288,
     MODULO = 289,
     MULT = 290,
     DIVIDE = 291,
     ADD = 292,
     SUBTRACT = 293,
     PERIOD = 294,
     LPAREN = 295,
     RPAREN = 296,
     LSQUARE = 297,
     RSQUARE = 298,
     LCURLY = 299,
     RCURLY = 300,
     COMMA = 301,
     SEMICOLON = 302,
     ASSIGNMENT = 303,
     COLON = 304,
     INCREMENT = 305,
     DECREMENT = 306,
     PUBLIC = 307,
     STATIC = 308,
     PRINT = 309
   };
#endif
/* Tokens.  */
#define BAD_TOKEN 258
#define DOUBLE 259
#define ELSE 260
#define FOR 261
#define IF 262
#define INT 263
#define RETURN 264
#define VOID 265
#define WHILE 266
#define CHAR 267
#define FLOAT 268
#define LONG 269
#define IDENTIFIER 270
#define CLASSNAME 271
#define CLASS 272
#define STRING 273
#define BOOL 274
#define INTLIT 275
#define DOUBLELIT 276
#define STRINGLIT 277
#define BOOLLIT 278
#define NULLVAL 279
#define LESSTHANOREQUAL 280
#define GREATERTHANOREQUAL 281
#define ISEQUALTO 282
#define NOTEQUALTO 283
#define LOGICALAND 284
#define LOGICALOR 285
#define LOGICNOT 286
#define GREATERTHAN 287
#define LESSTHAN 288
#define MODULO 289
#define MULT 290
#define DIVIDE 291
#define ADD 292
#define SUBTRACT 293
#define PERIOD 294
#define LPAREN 295
#define RPAREN 296
#define LSQUARE 297
#define RSQUARE 298
#define LCURLY 299
#define RCURLY 300
#define COMMA 301
#define SEMICOLON 302
#define ASSIGNMENT 303
#define COLON 304
#define INCREMENT 305
#define DECREMENT 306
#define PUBLIC 307
#define STATIC 308
#define PRINT 309




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 9 "j0gram.y"
{
   struct tree *treeptr;
}
/* Line 1529 of yacc.c.  */
#line 161 "j0gram.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

