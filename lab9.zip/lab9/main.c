#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"
#include "symt.h"
extern FILE *yyin;
extern int yyparse(FILE *f);
extern int yylex_destroy(void);
char *yyfilename;
#define SYMTAB_SIZE 7

int main(int argc, char *argv[]) {
	yyfilename = (char *)alloc(sizeof(char) * BUFF);
	if(strcmp(argv[1], "-dot") == 0){
		strcpy(yyfilename, argv[2]);
		if(strrchr(yyfilename, '.') == NULL){
			yyfilename = realloc(yyfilename, strlen(yyfilename) + sizeof(".java"));
			strcat(yyfilename, ".java\0");
		}else if (strcmp(strrchr(yyfilename, '.'), ".java") == 0){
			yyfilename[strlen(yyfilename)] = '\0';
		}else{
			printf("ERROR: Wrong File extension included\n");
			free(yyfilename);
			return -1;
		}
		yyin = fopen(yyfilename, "r");
    	int out = yyparse(yyin);
		if(out == 0){
			print_graph(root, "treegraph.dot");
		}else{
    		printf("yyparse returns %d\n", out);
		}

	//free memory
		//delete_st()
		free(yyfilename);
		fclose(yyin);
		freeTree(root);
		yylex_destroy();

	}else if(strcmp(argv[1], "-symtab") == 0){
		strcpy(yyfilename, argv[2]);
		if(strrchr(yyfilename, '.') == NULL){
			yyfilename = realloc(yyfilename, strlen(yyfilename) + sizeof(".java"));
			strcat(yyfilename, ".java\0");
		}else if (strcmp(strrchr(yyfilename, '.'), ".java") == 0){
			yyfilename[strlen(yyfilename)] = '\0';
		}else{
			printf("ERROR: Wrong File extension included\n");
			free(yyfilename);
			return -1;
		}
		yyin = fopen(yyfilename, "r");
    	int out = yyparse(yyin);
		if(out == 0){
			globals = buildglobal(globals);
			populate_symboltables(root);
			printf("----------Global Symbol Table----------\n");
			printsymbols(globals, 0);
			delete_st(globals);
		}else{
    		printf("yyparse returns %d\n", out);
		}
		//free memory
			free(yyfilename);
			fclose(yyin);
			freeTree(root);
			yylex_destroy();
	}else{
		strcpy(yyfilename, argv[1]);
		if(strrchr(yyfilename, '.') == NULL){
			yyfilename = realloc(yyfilename, strlen(yyfilename) + sizeof(".java"));
			strcat(yyfilename, ".java\0");
		}else if (strcmp(strrchr(yyfilename, '.'), ".java") == 0){
			yyfilename[strlen(yyfilename)] = '\0';
		}else{
			printf("ERROR: Wrong File extension included\n");
			free(yyfilename);
			return -1;
		}
		yyin = fopen(yyfilename, "r");
    	int out = yyparse(yyin);
		if(out == 0){
			printTree(root, 0);
		}else{
    		printf("yyparse returns %d\n", out);
		}

	//free memory
		free(yyfilename);
		fclose(yyin);
		freeTree(root);
		yylex_destroy();
	}
	return 0;
}
