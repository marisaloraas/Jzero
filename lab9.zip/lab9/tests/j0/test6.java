// https://www.programiz.com/java-programming/methods
public class test6 {
	//testing methods parameters
  public static int addNumbers(int a, int b) {
    int sum;
	sum = a + b;
    return sum;
  }

  public static int square(int num) {
    return num * num;
  }

  public static void main(String[] args) {
    int num1 = 25;
    int num2 = 15;
    int result1;
	int result2;
	result = addNumbers(num1, num2);
	result2 = square(num2);
    System.out.println("Sum is: " + result);
	System.out.println("The Square of Num2: " + result2);
  }
}
