public class test1 {
public static void main() {
   System.out.println("Hello\tworld\n");
} }
