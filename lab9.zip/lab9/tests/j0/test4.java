public class test4 {
	//A test of ForLoops
	public static int for1(){
		int z = 0;
		int y = 0;
		//missing statements
		for(; z < 10; z++){
			y+= z;
		}
		return y;
	}

	public static int for2(){
		int z = 20;
		for(; z > 0; ){
			z--;
		}
		return z;
	}

	public static void main() {
		//Nested For loop
		for(int i=1;i<=3;i++){
			for(int j=1;j<=3;j++){
        	System.out.println("Bark\n");
			}
		}
		for1();
		for2();
	}
}
