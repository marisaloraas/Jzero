public class test2 {
  public static int func() {
    int var_name = 7;
    return var_name;
    }
}
