// https://www.w3schools.com/java/tryjava.asp?filename=demo_if_else_if
public class test5 {
  public static void main() {
	//testing If eles blocks
    int time = 22;
    if (time < 10) {
      System.out.println("Good morning.");
    } else if (time < 20) {
      System.out.println("Good day.");
    }  else {
      System.out.println("Good evening.");
    }

	if(time != 10 || time >= 5){
		System.out.println("Should Work");
	}

	if(time > 10 && time < 20){
		System.out.println("Good Time of Day");
	} else {
		System.out.println("Bad Time of Day");
	}
  }
}
