public class semError1 {
	public static int test(int yes, int no){
		return yes + no;
	}
	public static void main() {
   		int variable1;
		variable1 = test(0, " ");
		//type checking
	}
}
