public class semError6 {
	public static int foo(){
		String answer = "STRING";
		return answer;
		//wrong return type so should fail
	}
	public static void main() {
		foo();
		return 0;
		//wrong return type so should fail
	}
}
