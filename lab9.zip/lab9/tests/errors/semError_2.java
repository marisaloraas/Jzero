public class semError2 {
	public static int test(int yes, int no){
		return yes + no;
	}
	public static void main() {
   		String variable1;
		//type checking
		variable1 = test(0, 1);
	}
}
