public class semError4 {
	public static void foo(){
		System.out.println("Bark\n");
	}
	public static void main() {
   		int variable1;
		variable1 = foo();
		//function call should not work because return type is void
	}
}
