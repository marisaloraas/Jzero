public class semError3 {
	public static void main() {
   		String variable1;
		variable1 = test(0, 1);
		//function call should not exsit or work
	}
}
