public class synError1 {
public static void main() {
   System.out.println("Hello\tworld\n");
   // Good Parenthesies
   /*
   Bad
   *
} }
