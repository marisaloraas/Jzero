//My version of J0 will only allow for all methods to be PUBLIC STATIC
public class j0Error_3 {
	public void test2(){
		System.out.println("Bark");
		return 1;
	}

	public static void main() {
		test2();
	}
}
