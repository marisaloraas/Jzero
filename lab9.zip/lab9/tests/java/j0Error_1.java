//Do while loops are included in java but not j0
public class j0Error_1 {
	public static void main() {
    	int i = 1;
    	do{
        	System.out.println(i);
    	i++;
    	}while(i<=10);
	}
}
