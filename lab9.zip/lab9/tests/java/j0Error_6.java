//No Object Oriented in my version of j0
//https://www.tutorialspoint.com/java/java_object_classes.htm
public class Dog {
	//allowed
   public static String breed;
   //not allowed
   int age;
   String color;

   void barking() {
   }

   void hungry() {
   }

   void sleeping() {
   }

	public Dog(){
	}
}
