#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "tree.h"
#include "j0gram.tab.h"
char *alloc(int n);

int serial;

int alctoken(int category){
	if(category == 1){
		fprintf(stderr, "Lexical Error: line %d in file %s\n"
		,yylineno, yyfilename);
		exit(1);
	}else{
		yylval.treeptr = (struct tree *)alloc(sizeof (struct tree));
		yylval.treeptr->prodrule = category;
		yylval.treeptr->symbolname = (char *)alloc(sizeof(char) * BUFF);
		strcpy(yylval.treeptr->symbolname, yytext);
		yylval.treeptr->nkids = 0;
		yylval.treeptr->id = serial++;
		yylval.treeptr->leaf = (struct token *)alloc(sizeof(struct token));
		yylval.treeptr->leaf->category = category;
		yylval.treeptr->leaf->text = (char *)alloc(sizeof(char) * BUFF);
		strcpy(yylval.treeptr->leaf->text, yytext);
		yylval.treeptr->leaf->lineno = yylineno;
		yylval.treeptr->leaf->filename = (char *)alloc(sizeof(char) * BUFF);
		strcpy(yylval.treeptr->leaf->filename, yyfilename);
		switch (category) {
			case 275:
				yylval.treeptr->leaf->ival = atoi(yytext);
				break;
			case 276:
				yylval.treeptr->leaf->dval = strtod(yytext, NULL);
				break;
			case 277:
				yylval.treeptr->leaf->sval = (char *)alloc(sizeof(char) * BUFF);
				strncpy(yylval.treeptr->leaf->sval, yytext, strlen(yytext)-1);
				break;
			default:
				yylval.treeptr->leaf->sval = NULL;
				break;
			}
	}
	return category;
}

struct tree *alctree(int prodrule, char *symbolname, int num, ...){
	va_list valist;
	int i;
	/* initialize valist for num number of arguments */
	va_start(valist, num);
	/* access all the arguments assigned to valist */
	struct tree * treeNode = (struct tree *)alloc(sizeof (struct tree));
	treeNode->prodrule = prodrule;
	treeNode->id = serial++;
	treeNode->symbolname = (char *)alloc(sizeof(char) * BUFF);
	strcpy(treeNode->symbolname, symbolname);
	treeNode->nkids = num;
	treeNode->leaf = NULL;
	for (i = 0; i < num; i++) {
		//treeNode->kids[i] = (struct tree *)alloc(sizeof (struct tree));
		treeNode->kids[i] = va_arg(valist, struct tree*);
   }
   /* clean memory reserved for valist */
   va_end(valist);
   return treeNode;
}

void yyerror(char *s){
   fprintf(stderr, "%s:%d: %s before '%s' token\n",
	   yyfilename, yylineno, s, yytext);
	free(yyfilename);
	exit(2);
}

/* For My testing purposes
void printnode(struct tree *treeptr) {
    struct token *temp = treeptr->leaf;
        printf("%d\t\t\t", temp->category);
        printf("%s\t\t\t", temp->text);
		printf("%d\t\t", temp->lineno);
        printf("%s\t\t", temp->filename);
        switch (temp->category) {
        case 274:
            printf("    %d\n", temp->ival);
            break;
        case 275:
            printf("    %f\n", temp->dval);
            break;
        case 276:
			for(int i = 1; i < strlen(temp->sval)-1; i++){
				printf("%c", temp->sval[i]);
			}
            printf("\n");
			break;
        default:
            printf("\n");
			break;
        }
}
*/
void printTree(struct tree *root, int level){
	int depth = root->nkids;
	for(int j = 0; j < level; j++){
		printf("\t");
	}
	if(depth == 0){
		printf("%s (%d): %d\n",root->leaf->text ,root->leaf->category, root->nkids);
	}else{
		level++;
		printf("%s (%d): %d\n",root->symbolname , root->prodrule, root->nkids);
		if(root->kids[0] == NULL){
			depth = 0;
		}
		for(int i = 0; i < depth; i++){
			printTree(root->kids[i], level);
		}
	}
}

void freeTree(struct tree *root){
	if(root->nkids == 0){
		//printf("bark\n");
		free(root->leaf->text);
		free(root->leaf->filename);
		if(root->leaf->category == 276)
			free(root->leaf->sval);
		free(root->leaf);
		free(root);
	}else{
		free(root->symbolname);
		int i = 0;
		while(i < root->nkids && root->kids[i]!= NULL){
			freeTree(root->kids[i]);
			i++;
		}
		free(root);
	}
}


/*DOT TREE IMPLEMENTATION */
/* add a \ before leading and trailing double quotes */

char *escape(char *s) {
   char *s2 = alloc(strlen(s)+4);
   if (s[0] == '\"') {
      if (s[strlen(s)-1] != '\"') {
	 fprintf(stderr, "What is it?!\n");
	 }
      sprintf(s2, "\\%s", s);
      strcat(s2+strlen(s2)-1, "\\\"");
      return s2;
     }
   else return s;
}

char *pretty_print_name(struct tree *t) {
   char *s2 = alloc(40);
   if (t->leaf == NULL) {
      sprintf(s2, "%s#%d", t->symbolname, t->prodrule%10);
      return s2;
      }
   else {
      sprintf(s2,"%s:%d", escape(t->leaf->text), t->leaf->category);
      return s2;
      }
}

void print_branch(struct tree *t, FILE *f) {
   fprintf(f, "N%d [shape=box label=\"%s\"];\n", t->id, pretty_print_name(t));
}

char *yyname(int);

void print_leaf(struct tree *t, FILE *f) {
   char * s = yyname(t->leaf->category);
   // print_branch(t, f);
   fprintf(f, "N%d [shape=box style=dotted label=\" %s \\n ", t->id, s);
   if(t->leaf->sval != NULL){
	   fprintf(f, "text = %s \\l lineno = %d \\l \"];\n", escape(t->leaf->sval), t->leaf->lineno);
   }else{
	   fprintf(f, "text = %s \\l lineno = %d \\l \"];\n", escape(t->leaf->text), t->leaf->lineno);
	}
}

void print_graph2(struct tree *t, FILE *f) {
   int i;
   if (t->leaf != NULL) {
      print_leaf(t, f);
      return;
      }
   /* not a leaf ==> internal node */
   print_branch(t, f);
   for(i=0; i < t->nkids; i++) {
      if (t->kids[i] != NULL) {
         fprintf(f, "N%d -> N%d;\n", t->id, t->kids[i]->id);
	 print_graph2(t->kids[i], f);
	 }
      else { /* NULL kid, epsilon production or something */
         fprintf(f, "N%d -> N%d%d;\n", t->id, t->id, serial);
	 fprintf(f, "N%d%d [label=\"%s\"];\n", t->id, serial, "Empty rule");
	 serial++;
	 }
      }
}

void print_graph(struct tree *t, char *filename){
      FILE *f = fopen(filename, "w"); /* should check for NULL */
      fprintf(f, "digraph {\n");
      print_graph2(t, f);
      fprintf(f,"}\n");
      fclose(f);
}
