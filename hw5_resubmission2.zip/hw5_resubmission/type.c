#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "type.h"
#include "symt.h"
#include "tree.h"
#include "j0gram.tab.h"

struct typeinfo null_type = { NULL_TYPE };
struct typeinfo integer_type = { INT_TYPE };
struct typeinfo double_type = { DOUBLE_TYPE };
struct typeinfo char_type = { CHAR_TYPE };
struct typeinfo string_type = {STRING_TYPE};
struct typeinfo float_type = {FLOAT_TYPE};
struct typeinfo bool_type = {BOOL_TYPE};
struct typeinfo long_type = {LONG_TYPE};
struct typeinfo void_type = {VOID_TYPE};


typeptr null_typeptr = &null_type;
typeptr integer_typeptr = &integer_type;
typeptr double_typeptr = &double_type;
typeptr char_typeptr = &char_type;
typeptr string_typeptr = &string_type;
typeptr float_typeptr = &float_type;
typeptr bool_typeptr = &bool_type;
typeptr long_typeptr = &long_type;
typeptr void_typeptr = &void_type;

char *typenam[] =
   {"null", "int", "array", "double", "func", "char", "String", "float",
	"bool", "long", "void", "class"};

typeptr alctype(int base)
{
   typeptr rv;
   if (base == NULL_TYPE) return null_typeptr;
   else if (base == INT_TYPE) return integer_typeptr;
   else if (base == DOUBLE_TYPE) return double_typeptr;
   else if (base == CHAR_TYPE) return char_typeptr;
   else if (base == STRING_TYPE) return string_typeptr;
   else if (base == FLOAT_TYPE) return float_typeptr;
   else if (base == BOOL_TYPE) return bool_typeptr;
   else if (base == LONG_TYPE) return long_typeptr;
   else if (base == VOID_TYPE) return void_typeptr;

   rv = (typeptr) calloc(1, sizeof(struct typeinfo));
   if (rv == NULL) return rv;
   rv->basetype = base;
   return rv;
}

typeptr alcarray(typeptr etype, struct tree *sz)//type and pointer
{
   typeptr rv = alctype(ARRAY_TYPE);
   rv->u.a.elemtype = etype;
   if (sz != NULL && sz->nkids==0 && sz->leaf->category==INTLIT) {
      rv->u.a.size = sz->leaf->ival;
      }
   else
      rv->u.a.size = 0;
   return rv;
}


/* in order for this to make any sense, you have to pass in the subtrees
 * for the return type (r) and the parameter list (p), but the calls to
 * to this function in the example are just passing NULL at present!
 */
typeptr alcfunctype(struct tree * n, SymbolTable st)
{
   typeptr rv = alctype(FUNC_TYPE);
   if (rv == NULL) return NULL;
   rv->u.f.st = st;
   rv->u.f.name = (char *) alloc(sizeof(char *) * BUFF);
   strcpy(rv->u.f.name, n->kids[1]->kids[0]->symbolname);
   //set equal to name of function
   rv->u.f.defined = 1; //check this
   /* fill in return type and paramlist by traversing subtrees */
   if(n->prodrule == 1082){
	   rv->u.f.returntype = alcarray(alctype(get_typenum(n->kids[0]->prodrule)), NULL);
   }else rv->u.f.returntype = alctype(get_typenum(n->kids[0]->prodrule));
  if(n->kids[1]->prodrule == 1091){
	 rv->u.f.nparams = 0;
	 rv->u.f.parameters = NULL;
 }else if(n->kids[1]->kids[1]->prodrule == 1500){//FormalParmList
	  rv->u.f.nparams = 0;
	  rv->u.f.parameters = (struct param *) alloc(sizeof(struct param));
	  for(int i = 0; i < n->kids[1]->kids[1]->nkids; i++){
		  if(n->kids[1]->kids[1]->kids[i]->prodrule == 1110){
			  rv->u.f.nparams += 1;
			  rv->u.f.parameters[rv->u.f.nparams-1].name = (char*) alloc(sizeof(char) * BUFF);
			  strcpy(rv->u.f.parameters[rv->u.f.nparams-1].name, n->kids[1]->kids[1]->kids[i]->kids[1]->symbolname);
			  rv->u.f.parameters[rv->u.f.nparams-1].type = alctype(get_typenum(n->kids[1]->kids[1]->kids[i]->kids[0]->prodrule));
			  if(rv->u.f.nparams > 1){
				  rv->u.f.parameters[rv->u.f.nparams-2].next = &rv->u.f.parameters[rv->u.f.nparams-1];
			  }
			  //if(i == n->kids[1]->kids[1]->nkids - 1){
				  //rv->u.f.parameters[i].next = NULL;
			  //}
		  }else if(n->kids[1]->kids[1]->kids[i]->prodrule == 1111){
			  rv->u.f.nparams += 1;
			  rv->u.f.parameters[rv->u.f.nparams - 1].name = (char*) alloc(sizeof(char) * BUFF);
			  strcpy(rv->u.f.parameters[rv->u.f.nparams - 1].name, n->kids[1]->kids[1]->kids[i]->kids[1]->symbolname);
			  rv->u.f.parameters[rv->u.f.nparams - 1].type = alcarray(alctype(get_typenum(n->kids[1]->kids[1]->kids[i]->kids[0]->prodrule)), n->kids[1]->kids[1]->kids[i]->kids[1]);
			  if(rv->u.f.nparams > 1){
				  rv->u.f.parameters[rv->u.f.nparams - 2].next = &rv->u.f.parameters[rv->u.f.nparams - 1];
			  }
			  //if(i == n->kids[1]->kids[1]->nkids - 1){
				  //rv->u.f.parameters[i].next = NULL;
			  //}
		  }else if(n->kids[1]->kids[1]->kids[i]->prodrule == 1500){
			  rv = insert_paramlist(n->kids[1]->kids[1]->kids[i], rv, rv->u.f.nparams);
		  }
	  }

  }else if(n->kids[1]->kids[1]->prodrule == 1111){
	  rv->u.f.nparams = 1;
	  rv->u.f.parameters = (struct param *) alloc(sizeof(struct param));
	  rv->u.f.parameters[0].name = (char*) alloc(sizeof(char) * BUFF);
	  strcpy(rv->u.f.parameters[0].name, n->kids[1]->kids[1]->kids[1]->symbolname);
	  rv->u.f.parameters[0].type = alcarray(alctype(get_typenum(n->kids[1]->kids[1]->kids[0]->prodrule)), NULL);
	  //insert param types
  }else if(n->kids[1]->kids[1]->prodrule == 1110){
	  rv->u.f.nparams = 1;
	  rv->u.f.parameters = (struct param *) alloc(sizeof(struct param));
	  rv->u.f.parameters[0].name = (char*) alloc(sizeof(char) * BUFF);
	  strcpy(rv->u.f.parameters[0].name, n->kids[1]->kids[1]->kids[1]->symbolname);
	  rv->u.f.parameters[0].type = alctype(get_typenum(n->kids[1]->kids[1]->kids[0]->prodrule));
  }
   /* rf->u.f.returntype = ... */
   return rv;
}


char *typename(typeptr t)
{
   if (!t) return "(NULL)";
   else if (t->basetype < FIRST_TYPE || t->basetype > LAST_TYPE){
      return "(BOGUS)";
  }else return typenam[t->basetype-1000000];
}

typeptr alc_class(char * n){
	typeptr rv = alctype(CLASS_TYPE);
    if (rv == NULL) return NULL;
	rv->u.c.name = (char*) alloc(sizeof(char) * BUFF);
	strcpy(rv->u.c.name, n);
	return rv;
}

typeptr alcfunctype2(int num_params, typeptr return_type, char * func_name){
	typeptr rv = alctype(FUNC_TYPE);
    if (rv == NULL) return NULL;
	rv->u.f.name = (char*) alloc(sizeof(char) * BUFF);
	strcpy(rv->u.f.name, func_name);
	rv->u.f.defined = 1;
	rv->u.f.st = NULL;
	rv->u.f.returntype = return_type;
	rv->u.f.nparams = num_params;
	rv->u.f.parameters = NULL;
	return rv;
}

int get_typenum(int t){
	if(t == 263) return INT_TYPE;
	else if(t == 279) return NULL_TYPE;
	else if (t == 259) return DOUBLE_TYPE;
	else if (t == 267) return CHAR_TYPE;
	else if (t == 273) return STRING_TYPE;
	else if (t == 268) return FLOAT_TYPE;
	else if (t == 274) return BOOL_TYPE;
	else if (t == 269) return LONG_TYPE;
	else if (t == 265) return VOID_TYPE;
	else return 0;

}

int evaluate_addexpr(SymbolTable st, struct tree *root){
	switch(root->prodrule){
		case 1340: case 1341:{//Add and Subb
			switch(root->kids[0]->prodrule){
				case IDENTIFIER:{
					if(lookup_st(st, root->kids[0]->symbolname) == NULL){
						fprintf(stderr, "Variable not declared error for %s at line %d ",root->kids[0]->symbolname, root->kids[0]->leaf->lineno);
						semanticerror("Variable not declared error", root->kids[0]);
						exit(3);
					}else{
						if(strcmp(typename(lookup_st(st, root->kids[0]->symbolname)->type), "string") == 0
						|| strcmp(typename(lookup_st(st, root->kids[0]->symbolname)->type), "bool") == 0
						|| strcmp(typename(lookup_st(st, root->kids[0]->symbolname)->type), "void") == 0
						|| strcmp(typename(lookup_st(st, root->kids[0]->symbolname)->type), "array") == 0
						|| strcmp(typename(lookup_st(st, root->kids[0]->symbolname)->type), "class") == 0){
							fprintf(stderr, "Bad opperand type for %s at line %d ",root->kids[0]->symbolname, root->kids[0]->leaf->lineno);
							semanticerror("Incorrect type error", root->kids[0]);
							exit(3);
						}
					}
					break;
				}
				case INTLIT: case DOUBLELIT: case CHARLIT:{
					break;
				}
				case BOOLLIT:{
					fprintf(stderr, "Bad opperand type for %s at line %d ",root->kids[0]->symbolname, root->kids[0]->leaf->lineno);
					semanticerror("Incorrect type error", root->kids[0]);
					exit(3);
					break;
				}
				case STRINGLIT:{
					fprintf(stderr, "String %s cannot be converted at line %d ",root->kids[0]->symbolname, root->kids[0]->leaf->lineno);
					semanticerror("Incorrect type error", root->kids[0]);
					exit(3);
					break;
				}
				case 1340: case 1341:{//Add and Sub Expr
					evaluate_addexpr(st, root->kids[0]);
					break;
				}
				case 1310: {//method call
				if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams == 0 && root->kids[0]->kids[0]->nkids > 1){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", root->kids[0]);
					exit(3);
				}
				if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams == 1 && (root->kids[0]->kids[1]->kids[1]->nkids = 0 || root->kids[0]->kids[1]->kids[1]->prodrule == 1290 || root->kids[0]->kids[1]->nkids > 1)){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[1]->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", root->kids[0]);
					exit(3);
				}else if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams == 2){
						if(root->kids[0]->kids[1]->prodrule != 1290){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[0]);
						exit(3);
					}else if(root->kids[0]->kids[1]->kids[0]->prodrule == 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[0]);
							exit(3);
						}
					}else if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams > 2){
						if(root->kids[0]->kids[1]->kids[0]->prodrule != 1290){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[0]);
						exit(3);
					}else if(root->kids[0]->kids[1]->kids[0]->prodrule == 1290){
							if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams != num_arlistopt(root->kids[0]->kids[1], 0)){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", root->kids[0]);
								exit(3);
							}
						}
					}
					if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams == 1){
						switch(root->kids[0]->kids[1]->prodrule){
							case IDENTIFIER:{
								if(strcmp(typename(lookup_st(st, root->kids[0]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case INTLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case DOUBLELIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case CHARLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case STRINGLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
							}
							case BOOLLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
							}
						}
					}else if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams == 2){
						switch(root->kids[0]->kids[1]->kids[0]->prodrule){
							case IDENTIFIER:{
								if(strcmp(typename(lookup_st(st, root->kids[0]->kids[1]->kids[0]->symbolname)->type), typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case INTLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case DOUBLELIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case CHARLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case STRINGLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
							}
							case BOOLLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
							}
						}
						switch(root->kids[0]->kids[1]->kids[1]->prodrule){
							case IDENTIFIER:{
								if(strcmp(typename(lookup_st(st, root->kids[0]->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type)) != 0
								&& strcmp(typename(lookup_st(st, root->kids[0]->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type)) != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case INTLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type), "int") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type), "long") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type), "int") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type), "long") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case DOUBLELIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type), "double") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type), "float") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type), "double") != 0
								&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type), "float") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case CHARLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type), "char") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type), "char") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[1]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
								break;
							}
							case STRINGLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type), "String") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type), "String") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[1]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
							}
							case BOOLLIT:{
								if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[1].type), "bool") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.parameters[3].type), "bool") != 0){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[1]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
							}
						}
					}else if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams > 2){
						//send in var2->kids[1]
						check_param_types(root->kids[0]->kids[1], lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type, 0, st->parent);
					}
					break;
				}

				case 1312:{//method calls
					if(lookup_st(st->parent, root->kids[0]->kids[1]->symbolname)->type->u.f.nparams == 0 && root->kids[0]->kids[2]->nkids > 1){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[0]);
						exit(3);
					}
					if(lookup_st(st->parent, root->kids[0]->kids[1]->symbolname)->type->u.f.nparams == 1 && (root->kids[0]->kids[2]->nkids = 0 || root->kids[0]->kids[1]->prodrule == 1290 || root->kids[0]->kids[1]->nkids > 1)){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[0]);
						exit(3);
					}else if(lookup_st(st->parent, root->kids[0]->kids[1]->symbolname)->type->u.f.nparams == 2){
							if(root->kids[0]->kids[2]->prodrule != 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[1]->symbolname, root->kids[0]->kids[1]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[0]);
							exit(3);
						}else if(root->kids[0]->kids[2]->kids[0]->prodrule == 1290){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[1]->symbolname, root->kids[0]->kids[1]->leaf->lineno);
								semanticerror("Icompatiable method call error", root->kids[0]);
								exit(3);
							}
						}else if(lookup_st(st->parent, root->kids[0]->kids[1]->symbolname)->type->u.f.nparams > 2){
							if(root->kids[0]->kids[2]->kids[0]->prodrule != 1290){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[2]->symbolname, root->kids[0]->kids[1]->leaf->lineno);
								semanticerror("Icompatiable method call error", root->kids[0]);
								exit(3);
							}else if(root->kids[0]->kids[2]->kids[0]->prodrule == 1290){
								if(lookup_st(st->parent, root->kids[0]->kids[1]->symbolname)->type->u.f.nparams != num_arlistopt(root->kids[0]->kids[1], 0)){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[2]->symbolname, root->kids[0]->kids[1]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[0]);
									exit(3);
								}
							}
						}
					break;
				}
				case 1314:{
					if(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.nparams > 0){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[0]);
						exit(3);
					}
					if(strcmp(typename(lookup_st(st->parent, root->kids[0]->kids[0]->symbolname)->type->u.f.returntype), "void") == 0){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[0]->kids[0]->symbolname, root->kids[0]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[0]);
						exit(3);
					}
					//another statement here
					break;
				}
			}
			if(root->nkids == 3){
				switch(root->kids[2]->prodrule){
					case IDENTIFIER:{
						if(lookup_st(st, root->kids[2]->symbolname) == NULL){
							fprintf(stderr, "Variable not declared error for %s at line %d ",root->kids[2]->symbolname, root->kids[2]->leaf->lineno);
							semanticerror("Variable not declared error", root->kids[2]);
							exit(3);
						}else{
							if(strcmp(typename(lookup_st(st, root->kids[2]->symbolname)->type), "string") == 0
							|| strcmp(typename(lookup_st(st, root->kids[2]->symbolname)->type), "bool") == 0
							|| strcmp(typename(lookup_st(st, root->kids[2]->symbolname)->type), "void") == 0
							|| strcmp(typename(lookup_st(st, root->kids[2]->symbolname)->type), "array") == 0
							|| strcmp(typename(lookup_st(st, root->kids[2]->symbolname)->type), "class") == 0){
								fprintf(stderr, "Bad opperand type for %s at line %d ",root->kids[2]->symbolname, root->kids[2]->leaf->lineno);
								semanticerror("Incorrect type error", root->kids[2]);
								exit(3);
							}
						}
						break;
					}
					case INTLIT: case DOUBLELIT: case CHARLIT:{
						break;
					}
					case BOOLLIT:{
						fprintf(stderr, "Bad opperand type for %s at line %d ",root->kids[2]->symbolname, root->kids[2]->leaf->lineno);
						semanticerror("Incorrect type error", root->kids[2]);
						exit(3);
						break;
					}
					case STRINGLIT:{

						fprintf(stderr, "String %s cannot be converted at line %d ",root->kids[2]->symbolname, root->kids[2]->leaf->lineno);
						semanticerror("Incorrect type error", root->kids[2]);
						exit(3);
						break;
					}
					case 1340: case 1341:{//Add and Sub Expr
						evaluate_addexpr(st, root->kids[2]);
						break;
					}
					case 1310: {//method call
					if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams == 0 && root->kids[2]->kids[0]->nkids > 1){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[2]);
						exit(3);
					}
					if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams == 1 && (root->kids[2]->kids[1]->kids[1]->nkids = 0 || root->kids[2]->kids[1]->kids[1]->prodrule == 1290|| root->kids[2]->kids[1]->nkids > 1)){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[1]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[2]);
						exit(3);
					}else if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams == 2){
							if(root->kids[2]->kids[1]->prodrule != 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[2]);
							exit(3);
						}else if(root->kids[2]->kids[1]->kids[0]->prodrule == 1290){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", root->kids[2]);
								exit(3);
							}
						}else if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams > 2){
							if(root->kids[2]->kids[1]->kids[0]->prodrule != 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[2]);
							exit(3);
						}else if(root->kids[2]->kids[1]->kids[0]->prodrule == 1290){
								if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams != num_arlistopt(root->kids[2]->kids[1], 0)){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[2]);
									exit(3);
								}
							}
						}
						if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams == 1){
							switch(root->kids[2]->kids[1]->prodrule){
								case IDENTIFIER:{
									if(strcmp(typename(lookup_st(st, root->kids[2]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case INTLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case DOUBLELIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case CHARLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case STRINGLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
								}
								case BOOLLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
								}
							}
						}else if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams == 2){
							switch(root->kids[2]->kids[1]->kids[0]->prodrule){
								case IDENTIFIER:{
									if(strcmp(typename(lookup_st(st, root->kids[2]->kids[1]->kids[0]->symbolname)->type), typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case INTLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case DOUBLELIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case CHARLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case STRINGLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
								}
								case BOOLLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
								}
							}
							switch(root->kids[2]->kids[1]->kids[1]->prodrule){
								case IDENTIFIER:{
									if(strcmp(typename(lookup_st(st, root->kids[2]->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type)) != 0
									&& strcmp(typename(lookup_st(st, root->kids[2]->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type)) != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case INTLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type), "long") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type), "long") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case DOUBLELIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type), "float") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type), "float") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case CHARLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type), "char") != 0
										&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type), "char") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[1]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
									break;
								}
								case STRINGLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type), "String") != 0
										&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type), "String") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[1]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
								}
								case BOOLLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[1].type), "bool") != 0
										&& strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.parameters[3].type), "bool") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[1]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
								}
							}
						}else if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams > 2){
							//send in var2->kids[1]
							check_param_types(root->kids[2]->kids[1], lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type, 0, st->parent);
						}
						break;
					}

					case 1312:{//method calls
						if(lookup_st(st->parent, root->kids[2]->kids[1]->symbolname)->type->u.f.nparams == 0 && root->kids[2]->kids[2]->nkids > 1){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[2]);
							exit(3);
						}
						if(lookup_st(st->parent, root->kids[2]->kids[1]->symbolname)->type->u.f.nparams == 1 && (root->kids[2]->kids[2]->nkids = 0 || root->kids[2]->kids[1]->prodrule == 1290 || root->kids[2]->kids[1]->nkids > 1)){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[2]);
							exit(3);
						}else if(lookup_st(st->parent, root->kids[2]->kids[1]->symbolname)->type->u.f.nparams == 2){
								if(root->kids[2]->kids[2]->prodrule != 1290){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[1]->symbolname, root->kids[2]->kids[1]->leaf->lineno);
								semanticerror("Icompatiable method call error", root->kids[2]);
								exit(3);
							}else if(root->kids[2]->kids[2]->kids[0]->prodrule == 1290){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[1]->symbolname, root->kids[2]->kids[1]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[2]);
									exit(3);
								}
							}else if(lookup_st(st->parent, root->kids[2]->kids[1]->symbolname)->type->u.f.nparams > 2){
								if(root->kids[2]->kids[2]->kids[0]->prodrule != 1290){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[2]->symbolname, root->kids[2]->kids[1]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[2]);
									exit(3);
								}else if(root->kids[2]->kids[2]->kids[0]->prodrule == 1290){
									if(lookup_st(st->parent, root->kids[2]->kids[1]->symbolname)->type->u.f.nparams != num_arlistopt(root->kids[2]->kids[1], 0)){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[2]->symbolname, root->kids[2]->kids[1]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[2]);
										exit(3);
									}
								}
							}
						break;
					}
					case 1314:{
						if(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.nparams > 0){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[2]);
							exit(3);
						}
						if(strcmp(typename(lookup_st(st->parent, root->kids[2]->kids[0]->symbolname)->type->u.f.returntype), "void") == 0){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[2]->kids[0]->symbolname, root->kids[2]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[2]);
							exit(3);
						}
						//another statement here
						break;
					}
				}
			}else if (root->nkids == 2){
				switch(root->kids[1]->prodrule){
					case IDENTIFIER:{
						if(lookup_st(st, root->kids[1]->symbolname) == NULL){
							fprintf(stderr, "Variable not declared error for %s at line %d ",root->kids[1]->symbolname, root->kids[1]->leaf->lineno);
							semanticerror("Variable not declared error", root->kids[1]);
							exit(3);
						}else{
							if(strcmp(typename(lookup_st(st, root->kids[1]->symbolname)->type), "string") == 0
							|| strcmp(typename(lookup_st(st, root->kids[1]->symbolname)->type), "bool") == 0
							|| strcmp(typename(lookup_st(st, root->kids[1]->symbolname)->type), "void") == 0
							|| strcmp(typename(lookup_st(st, root->kids[1]->symbolname)->type), "array") == 0
							|| strcmp(typename(lookup_st(st, root->kids[1]->symbolname)->type), "class") == 0){
								fprintf(stderr, "Bad opperand type for %s at line %d ",root->kids[1]->symbolname, root->kids[1]->leaf->lineno);
								semanticerror("Incorrect type error", root->kids[1]);
								exit(3);
							}
						}
						break;
					}
					case INTLIT: case DOUBLELIT: case CHARLIT:{
						break;
					}
					case BOOLLIT:{
						fprintf(stderr, "Bad opperand type for %s at line %d ",root->kids[1]->symbolname, root->kids[1]->leaf->lineno);
						semanticerror("Incorrect type error", root->kids[1]);
						exit(3);
						break;
					}
					case STRINGLIT:{
						fprintf(stderr, "String %s cannot be converted at line %d ",root->kids[1]->symbolname, root->kids[1]->leaf->lineno);
						semanticerror("Incorrect type error", root->kids[1]);
						exit(3);
						break;
					}
					case 1340: case 1341:{//Add and Sub Expr
						evaluate_addexpr(st, root->kids[1]);
						break;
					}
					case 1310: {//method call
					if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams == 0 && root->kids[1]->kids[0]->nkids > 1){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[1]);
						exit(3);
					}
					if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams == 1 && (root->kids[1]->kids[1]->kids[1]->nkids = 0 || root->kids[1]->kids[1]->kids[1]->prodrule == 1290 || root->kids[1]->kids[1]->nkids > 1)){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[1]->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", root->kids[1]);
						exit(3);
					}else if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams == 2){
							if(root->kids[1]->kids[1]->prodrule != 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[1]);
							exit(3);
						}else if(root->kids[1]->kids[1]->kids[0]->prodrule == 1290){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", root->kids[1]);
								exit(3);
							}
						}else if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams > 2){
							if(root->kids[1]->kids[1]->kids[0]->prodrule != 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[1]);
							exit(3);
							}else if(root->kids[1]->kids[1]->kids[0]->prodrule == 1290){
								if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams != num_arlistopt(root->kids[1]->kids[1], 0)){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[1]);
									exit(3);
								}
							}
						}
						if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams == 1){
							switch(root->kids[1]->kids[1]->prodrule){
								case IDENTIFIER:{
									if(strcmp(typename(lookup_st(st, root->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case INTLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case DOUBLELIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case CHARLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case STRINGLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
								}
								case BOOLLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
								}
							}
						}else if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams == 2){
							switch(root->kids[1]->kids[1]->kids[0]->prodrule){
								case IDENTIFIER:{
									if(strcmp(typename(lookup_st(st, root->kids[1]->kids[1]->kids[0]->symbolname)->type), typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case INTLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case DOUBLELIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case CHARLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case STRINGLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
								}
								case BOOLLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
								}
							}
							switch(root->kids[1]->kids[1]->kids[1]->prodrule){
								case IDENTIFIER:{
									if(strcmp(typename(lookup_st(st, root->kids[1]->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type)) != 0
									&& strcmp(typename(lookup_st(st, root->kids[1]->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type)) != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case INTLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type), "long") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type), "int") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type), "long") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case DOUBLELIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type), "float") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type), "double") != 0
									&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type), "float") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case CHARLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type), "char") != 0
										&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type), "char") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[1]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
									break;
								}
								case STRINGLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type), "String") != 0
										&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type), "String") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[1]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
								}
								case BOOLLIT:{
									if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[1].type), "bool") != 0
										&& strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.parameters[3].type), "bool") != 0){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[1]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
								}
							}
						}else if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams > 2){
							//send in var2->kids[1]
							check_param_types(root->kids[1]->kids[1], lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type, 0, st->parent);
						}
						break;
					}

					case 1312:{//method calls
						if(lookup_st(st->parent, root->kids[1]->kids[1]->symbolname)->type->u.f.nparams == 0 && root->kids[1]->kids[2]->nkids > 1){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[1]);
							exit(3);
						}
						if(lookup_st(st->parent, root->kids[1]->kids[1]->symbolname)->type->u.f.nparams == 1 && (root->kids[1]->kids[2]->nkids = 0 || root->kids[1]->kids[1]->prodrule == 1290)){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[1]);
							exit(3);
						}else if(lookup_st(st->parent, root->kids[1]->kids[1]->symbolname)->type->u.f.nparams == 2){
								if(root->kids[1]->kids[2]->prodrule != 1290){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[1]->symbolname, root->kids[1]->kids[1]->leaf->lineno);
								semanticerror("Icompatiable method call error", root->kids[1]);
								exit(3);
								}else if(root->kids[1]->kids[2]->kids[0]->prodrule == 1290){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[1]->symbolname, root->kids[1]->kids[1]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[1]);
									exit(3);
								}
							}else if(lookup_st(st->parent, root->kids[1]->kids[1]->symbolname)->type->u.f.nparams > 2){
								if(root->kids[1]->kids[2]->kids[0]->prodrule != 1290){
									fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[2]->symbolname, root->kids[1]->kids[1]->leaf->lineno);
									semanticerror("Icompatiable method call error", root->kids[1]);
									exit(3);
								}else if(root->kids[1]->kids[2]->kids[0]->prodrule == 1290){
									if(lookup_st(st->parent, root->kids[1]->kids[1]->symbolname)->type->u.f.nparams != num_arlistopt(root->kids[1]->kids[1], 0)){
										fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[2]->symbolname, root->kids[1]->kids[1]->leaf->lineno);
										semanticerror("Icompatiable method call error", root->kids[1]);
										exit(3);
									}
								}
							}
						break;
					}
					case 1314:{
						if(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.nparams > 0){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[1]);
							exit(3);
						}
						if(strcmp(typename(lookup_st(st->parent, root->kids[1]->kids[0]->symbolname)->type->u.f.returntype), "void") == 0){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",root->kids[1]->kids[0]->symbolname, root->kids[1]->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", root->kids[1]);
							exit(3);
						}
						//another statement here
						break;
					}
				}
			}
			break;
		}
	}
	return 0;
}

void check_litorident_type(SymbolTable st, struct tree *var1, struct tree *var2, struct tree *assignop){
	int argcount = 0;
	if(assignop->prodrule == ASSIGNMENT){
	switch(var2->prodrule){
		case INTLIT:{
			if(lookup_st(st, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "int") != 0 && strcmp(typename(lookup_st(st, var1->symbolname)->type), "float") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
				}
			}
			if(lookup_st(st->parent, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st->parent, var1->symbolname)->type), "int") != 0 && strcmp(typename(lookup_st(st, var1->symbolname)->type), "float") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
			}
			}
			break;
		}
		case DOUBLELIT:{
			if(lookup_st(st, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "double") != 0 && strcmp(typename(lookup_st(st, var1->symbolname)->type), "long") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
				}
			}
			if(lookup_st(st->parent, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st->parent, var1->symbolname)->type), "double") != 0 && strcmp(typename(lookup_st(st, var1->symbolname)->type), "long") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
			}
			}
			break;
		}
		case NULLVAL:{
			if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "String") != 0
				&& strcmp(typename(lookup_st(st, var1->symbolname)->type), "class") != 0
				&& strcmp(typename(lookup_st(st, var1->symbolname)->type), "char") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
			}
			break;
		}
		case STRINGLIT:{
			if(lookup_st(st, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "String") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
				}
			}
			if(lookup_st(st->parent, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st->parent, var1->symbolname)->type), "String") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
			}
			}
			break;
		}
		case CHARLIT:{
			if(lookup_st(st, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "char") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
				}
			}
			if(lookup_st(st->parent, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st->parent, var1->symbolname)->type), "char") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
			}
			}
			break;
		}
		case BOOLLIT:{
			if(lookup_st(st, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "bool") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
				}
			}
			if(lookup_st(st->parent, var1->symbolname) != NULL){
			if(strcmp(typename(lookup_st(st->parent, var1->symbolname)->type), "bool") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
			}
			}
			break;
		}
		case IDENTIFIER:{
			if(strcmp(typename(lookup_st(current, var2->symbolname)->type), "int") == 0 || strcmp(typename(lookup_st(current, var2->symbolname)->type), "float") == 0){
					if(strcmp(typename(lookup_st(current, var1->symbolname)->type), "int") != 0 && strcmp(typename(lookup_st(current, var1->symbolname)->type), "float") != 0){
						fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
						semanticerror("Variable type error", var1);
						exit(3);
					}
			}else if(strcmp(typename(lookup_st(current, var2->symbolname)->type), "double") == 0 || strcmp(typename(lookup_st(current, var2->symbolname)->type), "long") == 0){
					if(strcmp(typename(lookup_st(current, var1->symbolname)->type), "double") != 0 && strcmp(typename(lookup_st(current, var1->symbolname)->type), "long") != 0){
						fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
						semanticerror("Variable type error", var1);
						exit(3);
					}
			}else if(strcmp(typename(lookup_st(current, var2->symbolname)->type), "char") == 0){
					if(strcmp(typename(lookup_st(current, var1->symbolname)->type), "char") != 0){
						fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
						semanticerror("Variable type error", var1);
						exit(3);
					}
			}else if(strcmp(typename(lookup_st(current, var2->symbolname)->type), "String") == 0){
					if(strcmp(typename(lookup_st(current, var1->symbolname)->type), "String") != 0 && strcmp(typename(lookup_st(current, var1->symbolname)->type), "null") != 0){
						fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
						semanticerror("Variable type error", var1);
						exit(3);
					}
			}else if(strcmp(typename(lookup_st(current, var2->symbolname)->type), "bool") == 0){
					if(strcmp(typename(lookup_st(current, var1->symbolname)->type), "bool") != 0){
						fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
						semanticerror("Variable type error", var1);
						exit(3);
					}
				}
				break;
			}
			case 1310:{//method calls
			if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams == 0 && var2->kids[1]->nkids > 1){
				fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
				semanticerror("Icompatiable method call error", var2);
				exit(3);
			}
			if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams == 1 && (var2->kids[1]->nkids = 0 || var2->kids[1]->prodrule == 1290)){
				fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
				semanticerror("Icompatiable method call error", var2);
				exit(3);
			}else if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams == 2){
					if(var2->kids[1]->prodrule != 1290){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", var2);
					exit(3);
				}else if(var2->kids[1]->kids[0]->prodrule == 1290){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", var2);
						exit(3);
					}
				}else if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams > 2){
					if(var2->kids[1]->kids[0]->prodrule != 1290){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", var2);
					exit(3);
					}else if(var2->kids[1]->kids[0]->prodrule == 1290){
						if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams != num_arlistopt(var2->kids[1], 0)){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
							semanticerror("Icompatiable method call error", var2);
							exit(3);
						}
					}
				}
				if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams == 1){
					switch(var2->kids[1]->prodrule){
						case IDENTIFIER:{
							if(strcmp(typename(lookup_st(st, var2->kids[1]->symbolname)->type), typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case INTLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case DOUBLELIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case CHARLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case STRINGLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
						}
						case BOOLLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
						}
					}
				}else if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams == 2){
					switch(var2->kids[1]->kids[0]->prodrule){
						case IDENTIFIER:{
							if(strcmp(typename(lookup_st(st, var2->kids[1]->kids[0]->symbolname)->type), typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type)) != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case INTLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "int") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "long") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case DOUBLELIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "double") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "float") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case CHARLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "char") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case STRINGLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "String") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
						}
						case BOOLLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[0].type), "bool") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
						}
					}
					switch(var2->kids[1]->kids[1]->prodrule){
						case IDENTIFIER:{
							if(strcmp(typename(lookup_st(st, var2->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type)) != 0
							&& strcmp(typename(lookup_st(st, var2->kids[1]->kids[1]->symbolname)->type), typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type)) != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case INTLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type), "int") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type), "long") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type), "int") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type), "long") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case DOUBLELIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type), "double") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type), "float") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type), "double") != 0
							&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type), "float") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case CHARLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type), "char") != 0
								&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type), "char") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[1]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
							break;
						}
						case STRINGLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type), "String") != 0
								&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type), "String") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[1]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
						}
						case BOOLLIT:{
							if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[1].type), "bool") != 0
								&& strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.parameters[3].type), "bool") != 0){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[1]->symbolname, var2->kids[0]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
						}
					}
				}else if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams > 2){
					//send in var2->kids[1]
					check_param_types(var2->kids[1], lookup_st(st->parent, var2->kids[0]->symbolname)->type, 0, st->parent);
				}

				break;
			}
			case 1312:{//method calls
				if(lookup_st(st->parent, var2->kids[1]->symbolname)->type->u.f.nparams == 0 && var2->kids[2]->nkids > 1){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", var2);
					exit(3);
				}
				if(lookup_st(st->parent, var2->kids[1]->symbolname)->type->u.f.nparams == 1 && (var2->kids[2]->nkids = 0 || var2->kids[1]->prodrule == 1290)){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", var2);
					exit(3);
				}else if(lookup_st(st->parent, var2->kids[1]->symbolname)->type->u.f.nparams == 2){
						if(var2->kids[2]->prodrule != 1290){
						fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[1]->symbolname, var2->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", var2);
						exit(3);
						}else if(var2->kids[2]->kids[0]->prodrule == 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[1]->symbolname, var2->kids[1]->leaf->lineno);
							semanticerror("Icompatiable method call error", var2);
							exit(3);
						}
					}else if(lookup_st(st->parent, var2->kids[1]->symbolname)->type->u.f.nparams > 2){
						if(var2->kids[2]->kids[0]->prodrule != 1290){
							fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[2]->symbolname, var2->kids[1]->leaf->lineno);
							semanticerror("Icompatiable method call error", var2);
							exit(3);
						}else if(var2->kids[2]->kids[0]->prodrule == 1290){
							if(lookup_st(st->parent, var2->kids[1]->symbolname)->type->u.f.nparams != num_arlistopt(var2->kids[1], 0)){
								fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[2]->symbolname, var2->kids[1]->leaf->lineno);
								semanticerror("Icompatiable method call error", var2);
								exit(3);
							}
						}
					}
				break;
			}
			case 1314:{
				if(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.nparams > 0){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", var2);
					exit(3);
				}
				if(strcmp(typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.returntype), "void") == 0){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", var2);
					exit(3);
				}
				if(strcmp(typename(lookup_st(st->parent, var1->kids[0]->symbolname)->type), typename(lookup_st(st->parent, var2->kids[0]->symbolname)->type->u.f.returntype)) != 0){
					fprintf(stderr, "Icompatiable method call with %s at line %d ",var2->kids[0]->symbolname, var2->kids[0]->leaf->lineno);
					semanticerror("Icompatiable method call error", var2);
					exit(3);
				}
				break;
			}
		}
	}else if(assignop->prodrule == INCREMENT || assignop->prodrule == DECREMENT){
		if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "int") != 0
			&& strcmp(typename(lookup_st(st, var1->symbolname)->type), "float") != 0
			&& strcmp(typename(lookup_st(st, var1->symbolname)->type), "long") != 0
			&& strcmp(typename(lookup_st(st, var1->symbolname)->type), "double") != 0
			&& strcmp(typename(lookup_st(st, var1->symbolname)->type), "char") != 0
			&& strcmp(typename(lookup_st(st, var1->symbolname)->type), "func") != 0){
				fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
				semanticerror("Variable type error", var1);
				exit(3);
			}else{
				switch(var2->prodrule){
					case INTLIT: case CHARLIT: {
						break;
					}
					case DOUBLELIT:{
						if(strcmp(typename(lookup_st(st, var1->symbolname)->type), "double") != 0){
							fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
							semanticerror("Variable type error", var1);
							exit(3);
						}
						break;
					}
					case STRINGLIT: case NULLVAL: case BOOLLIT:{
						fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
						semanticerror("Variable type error", var1);
						exit(3);
						break;
					}
					case IDENTIFIER:{
						if(strcmp(typename(lookup_st(st, var2->symbolname)->type), "int") != 0
						&& strcmp(typename(lookup_st(st, var2->symbolname)->type), "float") != 0
						&& strcmp(typename(lookup_st(st, var2->symbolname)->type), "double") != 0
						&& strcmp(typename(lookup_st(st, var2->symbolname)->type), "char") != 0
						&& strcmp(typename(lookup_st(st, var2->symbolname)->type), "long") != 0){
							fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
							semanticerror("Variable type error", var1);
							exit(3);
						}
						break;
						}
					case 1310: case 1312: case 1314:{
						if(strcmp(typename(lookup_st(st, var2->kids[0]->symbolname)->type->u.f.returntype), "int") != 0
						&& strcmp(typename(lookup_st(st, var2->kids[0]->symbolname)->type->u.f.returntype), "float") != 0
						&& strcmp(typename(lookup_st(st, var2->kids[0]->symbolname)->type->u.f.returntype), "double") != 0
						&& strcmp(typename(lookup_st(st, var2->kids[0]->symbolname)->type->u.f.returntype), "char") != 0
						&& strcmp(typename(lookup_st(st, var2->kids[0]->symbolname)->type->u.f.returntype), "long") != 0){
							fprintf(stderr, "Variable type for %s cannot be assigned at line %d ",var1->symbolname, var1->leaf->lineno);
							semanticerror("Variable type error", var1);
							exit(3);
						}
						break;
					}
				}
			}
	}
}

typeptr insert_paramlist(struct tree *n, typeptr rv, int i){
	switch(n->prodrule){
		case 1500:{
			if(n->kids[0]->prodrule == 1110){
			rv->u.f.nparams += 1;
			//rv->u.f.parameters = (struct param *) alloc(sizeof(struct param));
			rv->u.f.parameters[rv->u.f.nparams-1].name = (char*) alloc(sizeof(char) * BUFF);
			strcpy(rv->u.f.parameters[rv->u.f.nparams-1].name, n->kids[0]->kids[1]->symbolname);
			rv->u.f.parameters[rv->u.f.nparams-1].type = alctype(get_typenum(n->kids[0]->kids[0]->prodrule));
		}else if(n->kids[0]->prodrule == 1111){
				rv->u.f.nparams += 1;
				//rv->u.f.parameters = (struct param *) alloc(sizeof(struct param));
				rv->u.f.parameters[rv->u.f.nparams].name = (char*) alloc(sizeof(char) * BUFF);
				strcpy(rv->u.f.parameters[rv->u.f.nparams].name, n->kids[1]->kids[1]->symbolname);
				rv->u.f.parameters[rv->u.f.nparams].type = alcarray(alctype(get_typenum(n->kids[1]->kids[0]->prodrule)), NULL);
		}
			if(i > 0){
				rv->u.f.parameters[rv->u.f.nparams-2].next = &rv->u.f.parameters[rv->u.f.nparams-1];
			}
	        if(n->kids[1]->prodrule == 1500){
				insert_paramlist(n->kids[1], rv, i++);
			}else if(n->kids[1]->prodrule == 1110){
				//rv->u.f.nparams += 1;
				//rv->u.f.parameters = (struct param *) alloc(sizeof(struct param));
				rv->u.f.parameters[rv->u.f.nparams].name = (char*) alloc(sizeof(char) * BUFF);
				strcpy(rv->u.f.parameters[rv->u.f.nparams].name, n->kids[1]->kids[1]->symbolname);
				rv->u.f.parameters[rv->u.f.nparams].type = alctype(get_typenum(n->kids[1]->kids[0]->prodrule));
				//rv->u.f.parameters->next = NULL;
			}else if(n->kids[1]->prodrule == 1111){
				rv->u.f.nparams += 1;
				//rv->u.f.parameters = (struct param *) alloc(sizeof(struct param));
				rv->u.f.parameters[rv->u.f.nparams].name = (char*) alloc(sizeof(char) * BUFF);
				strcpy(rv->u.f.parameters[rv->u.f.nparams].name, n->kids[1]->kids[1]->symbolname);
				rv->u.f.parameters[rv->u.f.nparams].type = alcarray(alctype(get_typenum(n->kids[1]->kids[0]->prodrule)), NULL);
				//rv->u.f.parameters->next = NULL;
			}
			break;
		}
	}
	return rv;
}


int num_arlistopt(struct tree *n, int num){

	switch(n->prodrule){
		case 1290:{
			if(n->kids[0]->prodrule == 1290){
				num = num_arlistopt(n->kids[0], num);
			}else if(n->kids[0]->prodrule != 1290){
				num+=1;
			}
			if(n->kids[1]->prodrule != 1290){
				num+=1;
			}
			break;
		}

	}
	return num;
}

int check_param_types(struct tree *n, typeptr function, int num, SymbolTable sn){
	switch(n->prodrule){
		case 1290:{
			if(n->kids[0]->prodrule == 1290){
				num = check_param_types(n->kids[0], function, num, sn);
			}else if(n->kids[0]->prodrule != 1290){
				num+=1;
				if(n->kids[0]->prodrule == IDENTIFIER){
					if(strcmp(typename(lookup_st(sn, n->kids[0]->symbolname)->type), typename(function->u.f.parameters[num].type)) != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[0]->symbolname, n->kids[0]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[0]->prodrule == INTLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "int") != 0
					&& strcmp(typename(function->u.f.parameters[num].type), "long") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[0]->prodrule == DOUBLELIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "double") != 0
					&& strcmp(typename(function->u.f.parameters[num].type), "float") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[0]->prodrule == CHARLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "char") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[0]->prodrule == STRINGLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "String") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}
				else if(n->kids[0]->prodrule == BOOLLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "bool") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}
			}
			if(n->kids[1]->prodrule != 1290){
				num+=1;
				if(n->kids[1]->prodrule == IDENTIFIER){
					if(strcmp(typename(lookup_st(sn, n->kids[1]->symbolname)->type), typename(function->u.f.parameters[num].type)) != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[1]->prodrule == INTLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "int") != 0
					&& strcmp(typename(function->u.f.parameters[num].type), "long") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[1]->prodrule == DOUBLELIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "double") != 0
					&& strcmp(typename(function->u.f.parameters[num].type), "float") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[1]->prodrule == CHARLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "char") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}else if(n->kids[1]->prodrule == STRINGLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "String") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}
				else if(n->kids[1]->prodrule == BOOLLIT){
					if(strcmp(typename(function->u.f.parameters[num].type), "bool") != 0){
						fprintf(stderr, "Icompatiable method call with param %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
						semanticerror("Icompatiable method call error", n);
						exit(3);
					}
				}
			}
			break;
		}
	}
	return num;
}

int check_return_statement(typeptr returntype , struct tree *n, SymbolTable st, int check){
	switch(n->prodrule){
		case 1150: {
			for(int i = 0; i < n->nkids; i++)
				check = check_return_statement(returntype, n->kids[i], st, check);
			break;
		}
		case 1270: {
			check = 1;
			if(n->kids[0] == NULL && strcmp(typename(returntype), "void") != 0){
				fprintf(stderr, "Icompatiable return %s at line %d ",n->symbolname, 666);
				semanticerror("Icompatiable return call error", n);
				exit(3);
			}else if(n->kids[0] == NULL && strcmp(typename(returntype), "void") == 0){
				break;
			}else{
				for(int i = 0; i < n->nkids; i++)
					check = check_return_statement(returntype, n->kids[i], st, check);
			}
			break;

		}
		case IDENTIFIER:{
			if(strcmp(typename(lookup_st(st, n->symbolname)->type), typename(returntype)) != 0){
				fprintf(stderr, "Icompatiable return %s at line %d ",n->symbolname, n->leaf->lineno);
				semanticerror("Icompatiable return call error", n);
				exit(3);
			}
			break;
		} case INTLIT: {
			if(strcmp(typename(returntype), "int") != 0 && strcmp(typename(returntype), "long") != 0 ){
				fprintf(stderr, "Icompatiable return %s at line %d ",n->symbolname, n->leaf->lineno);
				semanticerror("Icompatiable return call error", n);
				exit(3);
			}
			break;
		} case DOUBLELIT: {
			if(strcmp(typename(returntype), "double") != 0 && strcmp(typename(returntype), "float") != 0 ){
				fprintf(stderr, "Icompatiable return %s at line %d ",n->symbolname, n->leaf->lineno);
				semanticerror("Icompatiable return call error", n);
				exit(3);
			}
			break;
		} case CHARLIT: {
			if(strcmp(typename(returntype), "char") != 0){
				fprintf(stderr, "Icompatiable return %s at line %d ",n->symbolname, n->leaf->lineno);
				semanticerror("Icompatiable return call error", n);
				exit(3);
			}
			break;
		} case STRINGLIT: {
			if(strcmp(typename(returntype), "String") != 0){
				fprintf(stderr, "Icompatiable return %s at line %d ",n->symbolname, n->leaf->lineno);
				semanticerror("Icompatiable return call error", n);
				exit(3);
			}
			break;
		} case BOOLLIT: {
			if(strcmp(typename(returntype), "bool") != 0){
				fprintf(stderr, "Icompatiable return %s at line %d ",n->symbolname, n->leaf->lineno);
				semanticerror("Icompatiable return call error", n);
				exit(3);
			}
			break;
		}
		//more to check with return statement
	}
	return check;
}
