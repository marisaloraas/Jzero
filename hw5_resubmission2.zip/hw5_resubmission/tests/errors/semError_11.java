//dr j test class from hw 5
public class jstuff {
public static void main(String [] argv) {
  String m;
  m = "h";
  m = m + "3";
  m = m + "l";
  m = m + "l";
  m = m + "o";
  m = m + "\0";
  System.out.println("" + m);
}
}
