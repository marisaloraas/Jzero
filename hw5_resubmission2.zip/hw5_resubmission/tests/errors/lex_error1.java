public class lexError1 {
	private static void main() {
   		int variable1;

	}
}
