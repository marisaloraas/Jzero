public class semError2 {
	public static int test(int yes, int no){
		return yes + no;
	}
	public static void main() {
   		String variable1;
		int variable2;
		//type checking
		variable2 = test(1, "hello");
	}
}
