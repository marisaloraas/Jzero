public class semError5 {
	public static void foo(){
		System.out.println("Bark\n");
	}
	public static void main() {
   		int foo = 0;
		//should not work because foo is already defined
	}
}
