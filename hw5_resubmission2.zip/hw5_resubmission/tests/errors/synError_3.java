public class synError_3 {
  public static int func() {
    int var_name = 7;
	//missing semicolon
    return var_name
    }
}
