//dr jeffery test from hw5
public class typeck {
public static int fib(int i) {
   return 11;
}

public static void main(String [] argv) {
   int i;
   i = 0 + fib();
   return 0;
}
}
