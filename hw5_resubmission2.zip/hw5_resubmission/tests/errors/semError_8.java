//dr jeffery test from hw5
//fix
public class typeck_fn {
public static int fib(int i) {
   return 11;
}
public static int main(String [] argv) {
   int i ;
   i = 0 + fib(1,2);
   return 0;
}
}
