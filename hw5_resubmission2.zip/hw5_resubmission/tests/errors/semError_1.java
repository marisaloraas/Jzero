public class semError1 {
	public static int test(int yes, int no){
		return yes + no;
	}
	public static void main() {
   		int variable1;
		char variable2;
		variable1 = variable2;
		//type checking
	}
}
