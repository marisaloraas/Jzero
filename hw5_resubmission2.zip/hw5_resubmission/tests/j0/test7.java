//Dr jeffery test from hw5
public class basic {
public static int x ;
public static void main(String []argv) {
   x = 5;
   x = x * x;
}
}
