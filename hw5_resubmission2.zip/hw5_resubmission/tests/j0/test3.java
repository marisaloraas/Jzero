public class test3 {
// A test of while loop syntax
// Used from Dr. J's example cases and slightly changed
public static int foo() {
	int x46;
	return x46 != 30;
}

public static int main() {
	int test1;
	int test2;
        // infinite loop
	while (1) {
		test1 = test1 + 1;

	}
	// While loop with incrementing variable
	test1 = 0;
	while (test1 < 10) {
		test1 = test1 + 1;
	}

	// While loop with different expression
	test2 = 0;
	while (test2 != 1) {
		test2 = 1;
	}

	// While loop with function call (and empty body)
	while (foo()) {

	}
		return 0;
	}

}
