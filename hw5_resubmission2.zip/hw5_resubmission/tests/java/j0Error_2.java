//Switch Statesments are allowed in Java but not my version of J0
public class j0Error_2 {
public static void main() {
    int test = 20;
    //Switch expression
    switch(test){
    case 5:
		System.out.println("GOT IT");
    	break;
    case 10:
		System.out.println("GOT IT");
    	break;
    case 15:
		System.out.println("GOT IT");
		break;
	case 20:
		System.out.println("GOT IT");
		break;
    default:
		System.out.println("Sad Days");
    }
}
}
