//My version of J0 will only allow for all methods to be PUBLIC STATIC
public class j0Error_4 {
	private int test3(){
		System.out.println("Bark");
		return 1;
	}

	public static void main() {
		test3();
	}
}
