//No Object Oriented in my version of j0
//https://www.tutorialspoint.com/java/java_object_classes.htm
public class Dog {

	public Dog(){
	}
	
   void barking() {
   }

   void hungry() {
   }

   void sleeping() {
   }

}
