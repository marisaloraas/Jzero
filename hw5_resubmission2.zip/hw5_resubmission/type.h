#ifndef TYPE_H
#define TYPE_H

#include "tree.h"
typedef struct param {
   char *name;
   struct typeinfo *type;
   struct param *next;
   } *paramlist;

/* base types. How many more base types do we need? */
#define FIRST_TYPE   1000000

#define NULL_TYPE    1000000
#define INT_TYPE     1000001
#define ARRAY_TYPE   1000002
#define DOUBLE_TYPE  1000003
#define FUNC_TYPE    1000004
#define CHAR_TYPE    1000005
#define STRING_TYPE  1000006
#define FLOAT_TYPE   1000007
#define BOOL_TYPE    1000008
#define LONG_TYPE    1000009
#define VOID_TYPE    1000010
#define CLASS_TYPE   1000011

#define LAST_TYPE    1000011

typedef struct typeinfo {
   int basetype;
   union {
      struct arrayinfo {
         int size;
	 struct typeinfo *elemtype;
         }a;
      struct funcinfo {
	 char *name; /* ? */
	 int defined; /* 0 == prototype, 1 == not prototype */
	 struct sym_table *st;
	 struct typeinfo *returntype;
	 int nparams;
	 struct param *parameters;
	 }f;
	 struct classinfo{
		 char* name;
	 }c;
      } u;
   } *typeptr;

extern struct sym_table *global_table;

typeptr alctype(int);
typeptr alcarray(typeptr, struct tree *);
typeptr alcfunctype(struct tree * n, SymbolTable st);
typeptr alcfunctype2(int num_params, typeptr return_type, char * func_name);
typeptr alc_class(char * n);
char *typename(typeptr t);
int get_typenum(int t);
int evaluate_addexpr(SymbolTable st, struct tree *root);
void check_litorident_type(SymbolTable st, struct tree *var1, struct tree *var2, struct tree *assignop);
typeptr insert_paramlist(struct tree *n, typeptr rv, int i);
int num_arlistopt(struct tree *n, int num);
int check_param_types(struct tree *n, typeptr function, int num, SymbolTable sn);
int check_return_statement(typeptr returntype , struct tree *n, SymbolTable st, int check);

extern typeptr integer_typeptr;
extern typeptr double_typeptr;
extern typeptr char_typeptr;
extern typeptr null_typeptr;
extern typeptr string_typeptr;
extern char *typenam[];

#endif
