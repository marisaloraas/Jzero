#!/bin/bash
make
cd tests/j0/
echo Printing j0 tests...
./../../j0 test1.java
./../../j0 test2.java
./../../j0 test3.java
./../../j0 test4.java
./../../j0 test5.java
./../../j0 test6.java
./../../j0 test6.java

cd ..
cd errors
echo Printing error tests...
./../../j0 lex_error1.java
./../../j0 synError_1.java
./../../j0 synError_2.java
./../../j0 synError_3.java
./../../j0 semError_1.java
./../../j0 semError_2.java
./../../j0 semError_3.java
./../../j0 semError_4.java
./../../j0 semError_5.java
./../../j0 semError_6.java
./../../j0 semError_7.java
./../../j0 semError_8.java
./../../j0 semError_9.java
./../../j0 semError_10.java
./../../j0 semError_11.java

cd ..
cd java
echo Printing J0 errors in java folder...
./../../j0 j0Error_1.java
./../../j0 j0Error_2.java
./../../j0 j0Error_3.java
./../../j0 j0Error_4.java
./../../j0 j0Error_5.java
./../../j0 j0Error_6.java
./../../j0 j0Error_7.java
echo NOTE: all of the tests do not run as they should
cd ..
cd ..
