/*
* @filename lab2_2.c
* @author Marisa Loraas
* @Date 2/5/22
*/
#include <stdio.h>
extern FILE *yyin;
extern int yylex(void);
extern int rows, words, chars;
extern char *yytext;

int main(int argc, char *argv[]) {
	 	yyin = fopen(argv[1], "r");
		int temp = 0;
    while((temp = yylex()) != 0) {
			if(temp == 666)
				break;
        printf("%d ->\t %s\n", temp, yytext);
    }
		if(temp != 666){
    printf("\t%d\t%d\n", words, chars);
		}
		fclose(yyin);
    return 0;
}
