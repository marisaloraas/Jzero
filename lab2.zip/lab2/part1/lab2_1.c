/*
* @filename lab2_1.c
* @author Marisa Loraas
* @Date 2/5/22
*/
#include <stdio.h>
extern FILE *yyin;
extern int yylex(void);
extern int rows, words, chars;

int main(int argc, char *argv[]) {
	 	yyin = fopen(argv[1], "r");
    yylex();
    printf("\t%d\t%d\t%d\n", rows, words, chars);
		fclose(yyin);
    return 0;
}
