#ifndef HEADER_FILE
#define HEADER_FILE
#include <stdio.h>
#include <stdbool.h>
#define BUFF 1024
extern int yylineno;
extern char *yytext;
extern char *yyfilename;

struct tree {
   int prodrule;
   char *symbolname;
   int id;
   int nkids;
   struct tree *kids[9]; /* if nkids >0 */
   struct token *leaf;   /* if nkids == 0; NULL for ε productions */
   bool isConst;
   struct SymbolTable *stab;
};

struct token {
   int category;   /* the integer code returned by yylex */
   char *text;     /* the actual string (lexeme) matched */
   int lineno;     /* the line number on which the token occurs */
   char *filename; /* the source file in which the token occurs */
   int ival;       /* for integer constants, store binary value here */
   double dval;	   /* for real constants, store binary value here */
   char *sval;     /* for string constants, malloc space, de-escape, store */
                   /*    the string (less quotes and after escapes) here */
   };

struct tree *root;

int alctoken(int category);
void yyerror(char *s);
void printnode(struct tree *treeptr);
struct tree *alctree(int prodrule, char *symbolname, int num, ...);
void printTree(struct tree *root, int level);
void freeTree(struct tree *root);
char * alloc(int n);

#endif
