/*
 * symt.c
 */

/*
 * The functions in this file maintain a hash table mapping strings to
 *   symbol table entries.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symt.h"
#include "tree.h"
#include "j0gram.tab.h"


/*
 * new_st - construct symbol (hash) table.
 *  Allocate space first for the structure, then
 *  for the array of buckets.
 */
SymbolTable new_st(int nbuckets)
   {
   int h;
   SymbolTable rv;
   rv = (SymbolTable) alloc(sizeof(struct sym_table));
   rv->tbl = (struct sym_entry **)
      alloc((unsigned int)(nbuckets * sizeof(struct sym_entry *)));
   rv->nBuckets = nbuckets;
   rv->nEntries = 0;
   return rv;
   }

/*
 * delete_st - destruct symbol table.
 */
void delete_st(SymbolTable st)
   {
   SymbolTableEntry se, se1;
   int h;

   for (h = 0; h < st->nBuckets; ++h)
      for (se = st->tbl[h]; se != NULL; se = se1) {
         se1 = se->next;
	 free((char *)se->s); /* strings in the table were all strdup'ed. */
         free((char *)se);
         }
   free((char *)st->tbl);
   free((char *)st);
   }

/*
 * Compute hash value.
 */
int hash(SymbolTable st, char *s)
{
   register int h = 0;
   register char c;
   while ((c = *s++)) {
      h += c & 0377;
      h *= 37;
      }
   if (h < 0) h = -h;
   return h % st->nBuckets;
}

/*
 * Insert a symbol into a symbol table.
 */
int insert_sym(SymbolTable st, char *s)// typeptr t, ask about this third argument
{
   register int i;
   int h;
   struct sym_entry *se;
   int l;

   h = hash(st, s);
   for (se = st->tbl[h]; se != NULL; se = se->next)
      if (!strcmp(s, se->s)) {
         return 0;
         }

   /*
    * The string is not in the table. Add the copy from the
    *  buffer to the table.
    */
   se = (SymbolTableEntry)alloc((unsigned int) sizeof (struct sym_entry));
   se->next = st->tbl[h];
   se->table = st;
   st->tbl[h] = se;
   se->s = strdup(s);
   // removed for now: se->type = t;
   st->nEntries++;
   return 1;
}

/*
 * lookup_st - search the symbol table for a given symbol, return its entry.
 */
SymbolTableEntry lookup_st(SymbolTable st, char *s)
   {
   register int i;
   int h;
   SymbolTableEntry se;

   h = hash(st, s);
   for (se = st->tbl[h]; se != NULL; se = se->next)
      if (!strcmp(s, se->s)) {
         return se;
         }
   return NULL;
   }



char * alloc(int n)
{
   char *a = calloc(n, sizeof(char));
   if (a == NULL) {
      fprintf(stderr, "alloc(%d): out of memory\n", (int)n);
      exit(-1);
      }
   return a;
}

void enter_newscope(char *s)
{
   /* allocate a new symbol table */
   SymbolTable table = (SymbolTable)alloc((unsigned int) sizeof (struct sym_table));
   /* insert s into current symbol table */
   insert_sym(current, s);
   /* attach new symbol table to s's symbol table in the current symbol table*/

	//Work on this

   /* push new symbol on the stack, making it the current symbol table */
   pushscope(table);
}

void populate_symboltables(struct tree * n)
{
   int i;
   if (n == NULL) return;
   /* pre-order activity */
   switch (n->prodrule) {
   case 1070: case 1310: case 1000: {  /* MethodDecl, MethodCall, ClassDecl
   									whatever production rule(s) enter a function scope */
     enter_newscope(n->leaf->text);
     break;
     }
   /*whatever production rule(s) enter a struct scope
		Does this mean for loops and while loops? No struct or switch in j0.1
		specification
   */
   /*case : {
     enter_newscope();
     break;
 }*/ /* label of new struct  inside enter new scope*/
   case 1050: case 1170 :{ /* "VarDecls", "LocalVarDecl" whatever production rule(s) designate a variable declaration*/
       /* figure out which kid is a "list" of variables */
	   /*Check */
	   if(n->nkids >= 2){
		   for(int i = 0; i < n->nkids; i++){
			   if(n->kids[i]->nkids != 0){
				   populate_symboltables(n->kids[i]);
			   }else{
				   dovariabledeclarator(n);
			   }
		   }
	   }else{
		   insert_sym(current, n->kids[0]->symbolname);
	   }
       /* walk through the subtree that is the list of variables */
            /* for each variable, insert it into the current symbol table*/
       break;
   }
   case IDENTIFIER /* IDENTIFIER whatever leaf denotes a variable name */: {
      SymbolTableEntry ste = NULL;
      SymbolTable st = current;
      /* check if the symbol is already defined in current scope */
	  if(lookup_st(st, n->symbolname) != NULL){
		  //fprintf(stderr, "Redeclaration error for %s\ at line %d",n->symbolname, n->lineno);
		  semanticerror("Redeclaration error", n);
		   /*   if it is, report a redeclaration error */
	  }else{
		  	ste = (SymbolTableEntry)alloc((unsigned int) sizeof (struct sym_entry));
			strcpy(ste->s, n->symbolname);
			ste->table = st;
		  	insert_sym(st, ste->s);
			 /*   if it is not, insert it into the current symbol table */
	  }
	  break;
      }
   }
   /* visit children */
   for (i=0; i<n->nkids; i++)
      populate_symboltables(n->kids[i]);

   /* post-order activity */
   switch (n->prodrule) {
   case 1070/* MethodDecl we are back out to a node where we entered a subscope */:
     popscope();
     break;
   }
}

void dovariabledeclarator(struct tree * n)
{
  /* in future look for type information (e.g. array, pointer) modifiers */
  /* get variable ident */

  //insert_sym(current, ident);
}

void printsymbols(SymbolTable st, int level)
{
   int i, j;
   SymbolTableEntry ste;
   if (st == NULL) return;
   for (i=0;i<st->nBuckets;i++) {
      for (ste = st->tbl[i]; ste; ste=ste->next) {
	 for (j=0; j < level; j++) printf("  ");
	 printf("%s\n", ste->s);

	 /* if this symbol has a subscope, print it recursively, indented
	 printsymbols( // subscope symbol table
                    , level+1);
          */
      }
   }
}

void semanticerror(char *s, struct tree * n)
{
   while (n && (n->nkids > 0))
   		n=n->kids[0];
   if (n) {
     fprintf(stderr, "%s:%d: ", n->leaf->filename, n->leaf->lineno);
   }
  fprintf(stderr, "%s", s);
  if (n && n->prodrule == IDENTIFIER)
  	fprintf(stderr, " %s", n->leaf->text);
  fprintf(stderr, "\n");
  errors++;
}
