/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     DOUBLE = 258,
     ELSE = 259,
     FOR = 260,
     IF = 261,
     INT = 262,
     RETURN = 263,
     VOID = 264,
     WHILE = 265,
     CHAR = 266,
     FLOAT = 267,
     LONG = 268,
     IDENTIFIER = 269,
     CLASSNAME = 270,
     CLASS = 271,
     STRING = 272,
     BOOL = 273,
     INTLIT = 274,
     DOUBLELIT = 275,
     STRINGLIT = 276,
     BOOLLIT = 277,
     NULLVAL = 278,
     LESSTHANOREQUAL = 279,
     GREATERTHANOREQUAL = 280,
     ISEQUALTO = 281,
     NOTEQUALTO = 282,
     LOGICALAND = 283,
     LOGICALOR = 284,
     LOGICNOT = 285,
     GREATERTHAN = 286,
     LESSTHAN = 287,
     MODULO = 288,
     MULT = 289,
     DIVIDE = 290,
     ADD = 291,
     SUBTRACT = 292,
     PERIOD = 293,
     LPAREN = 294,
     RPAREN = 295,
     LSQUARE = 296,
     RSQUARE = 297,
     LCURLY = 298,
     RCURLY = 299,
     COMMA = 300,
     SEMICOLON = 301,
     ASSIGNMENT = 302,
     COLON = 303,
     INCREMENT = 304,
     DECREMENT = 305,
     PUBLIC = 306,
     STATIC = 307,
     PRINT = 308
   };
#endif
/* Tokens.  */
#define DOUBLE 258
#define ELSE 259
#define FOR 260
#define IF 261
#define INT 262
#define RETURN 263
#define VOID 264
#define WHILE 265
#define CHAR 266
#define FLOAT 267
#define LONG 268
#define IDENTIFIER 269
#define CLASSNAME 270
#define CLASS 271
#define STRING 272
#define BOOL 273
#define INTLIT 274
#define DOUBLELIT 275
#define STRINGLIT 276
#define BOOLLIT 277
#define NULLVAL 278
#define LESSTHANOREQUAL 279
#define GREATERTHANOREQUAL 280
#define ISEQUALTO 281
#define NOTEQUALTO 282
#define LOGICALAND 283
#define LOGICALOR 284
#define LOGICNOT 285
#define GREATERTHAN 286
#define LESSTHAN 287
#define MODULO 288
#define MULT 289
#define DIVIDE 290
#define ADD 291
#define SUBTRACT 292
#define PERIOD 293
#define LPAREN 294
#define RPAREN 295
#define LSQUARE 296
#define RSQUARE 297
#define LCURLY 298
#define RCURLY 299
#define COMMA 300
#define SEMICOLON 301
#define ASSIGNMENT 302
#define COLON 303
#define INCREMENT 304
#define DECREMENT 305
#define PUBLIC 306
#define STATIC 307
#define PRINT 308




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 8 "j0gram.y"
{
   struct tree *treeptr;
}
/* Line 1529 of yacc.c.  */
#line 159 "j0gram.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

