#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"
extern FILE *yyin;
extern int yyparse(FILE *f);
extern int yylex_destroy(void);
char *yyfilename;

int main(int argc, char *argv[]) {
	yyfilename = (char *)malloc(sizeof(char) * BUFF);
	strcpy(yyfilename, argv[1]);
	if(strrchr(yyfilename, '.') == NULL){
		yyfilename = realloc(yyfilename, strlen(yyfilename) + sizeof(".java"));
		strcat(yyfilename, ".java\0");
	}else if (strcmp(strrchr(yyfilename, '.'), ".java") == 0){
		yyfilename[strlen(yyfilename)] = '\0';
	}else{
		printf("ERROR: Wrong File extension included\n");
		free(yyfilename);
		return -1;
	}
	//root = (struct tree *)malloc(sizeof (struct tree));
	yyin = fopen(yyfilename, "r");
    int out = yyparse(yyin);
	if(out == 0){
		printTree(root, 0);
	}else{
    	printf("yyparse returns %d\n", out);
	}
	//free memory
	free(yyfilename);
	fclose(yyin);
	freeTree(root);

	yylex_destroy();
	return 0;
}
