#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"
#include "j0gram.tab.h"
extern int rows;
extern char *yytext;
extern char *file_name;

int alctoken(int category){
	yylval.treeptr = (struct tree *)malloc(sizeof (struct tree));
	yylval.treeptr->prodrule = category;
	yylval.treeptr->symbolname = (char *)malloc(sizeof(char *));
	yylval.treeptr->nkids= 0;
	yylval.treeptr->leaf = (struct token *)malloc(sizeof(struct token));
	yylval.treeptr->leaf->category = category;
	yylval.treeptr->leaf->text = (char *)malloc(sizeof(char) * strlen(yytext));
	strcpy(yylval.treeptr->leaf->text, yytext);
	yylval.treeptr->leaf->lineno = rows;
	yylval.treeptr->leaf->filename = (char *)malloc(sizeof(char) * strlen(file_name));
	strcpy(yylval.treeptr->leaf->filename, file_name);
	//tok->filename = (char *)malloc(sizeof(char) * flength);
	//tok->lineno = rows;
	//strncpy(tok->filename, fname, flength);
	switch (category) {
		case 274:
			yylval.treeptr->leaf->ival = atoi(yytext);
			//printf("ival: %d yytext: %d\n", tok->ival, atoi(yytext));
			break;
		case 275:
			yylval.treeptr->leaf->dval = strtod(yytext, NULL);
			break;
		case 276:
			yylval.treeptr->leaf->sval = (char *)malloc(sizeof(char) * strlen(yytext));
			strcpy(yylval.treeptr->leaf->sval, yytext);
			break;
		}
	return category;
}

char *check_filename(char *fname, int flength){
	char *temp = NULL;
	if(strrchr(fname, '.') == temp){
		temp = (char *) realloc(fname, flength + sizeof(".java"));
		strncat(temp, ".java\0", 6);
		strcpy(file_name, temp);
		return temp;
	}else if (strcmp(strrchr(fname, '.'), ".java") == 0){
		fname[flength] = '\0';
		strcpy(file_name, fname);
		return fname;
	}else{
    	return "ERROR";
	}
}

int yyerror(char *s) {
   fprintf(stderr, "%s\n Please consider looking at all the work I did in all the Files, I'm struggling to stop this from printing", s); exit(1);
}

void printnode(struct tree *treeptr) {
    struct token *temp = treeptr->leaf;
	printf("Category \t\t Text \t\t Lineno \t\t Filename\t\t Ival/Sval\t\t\n\n");
        printf("%d\t\t\t", temp->category);
        printf("%s\t\t\t", temp->text);
		printf("%d\t\t", temp->lineno);
        printf("%s\t\t", temp->filename);
        switch (temp->category) {
        case 274:
            printf("    %d\n", temp->ival);
            break;
        case 275:
            printf("    %f\n", temp->dval);
            break;
        case 276:
            printf("%s\n", temp->sval);
			break;
        default:
            printf("\n");
			break;
        }
}
