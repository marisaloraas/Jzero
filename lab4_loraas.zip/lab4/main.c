#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"
extern FILE *yyin;
extern int yyparse(FILE *f);
char *file_name;

int main(int argc, char *argv[]) {
	file_name = (char *)malloc(sizeof(char)*(strlen(argv[1])+6));
	strcpy(file_name, argv[1]);
	/*
	Still trying to fix this
	file_name = check_filename(file_name, strlen(file_name));
	if(strcmp(file_name, "ERROR") == 0){
		printf("ERROR: Wrong File extension included\n");
		return -1;
	}*/
	//I really did try so hard on this lab, I'm sorry
	yyin = fopen(argv[1], "r");
    int out = yyparse(yyin);
    printf("yyparse returns %d\n", out);
	free(file_name);
	fclose(yyin);
	return 0;
}
