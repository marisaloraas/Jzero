/*
 * symt.c
 * TO DO: Undefined errors
 */

/*
 * The functions in this file maintain a hash table mapping strings to
 *   symbol table entries.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symt.h"
#include "tree.h"
#include "j0gram.tab.h"
#define SYMTAB_SIZE 7
/*
 * new_st - construct symbol (hash) table.
 *  Allocate space first for the structure, then
 *  for the array of buckets.
 */
SymbolTable new_st(int nbuckets)
   {
   //int h;
   SymbolTable rv;
   rv = (SymbolTable) alloc(sizeof(struct sym_table));
   rv->tbl = (struct sym_entry **)
      alloc((unsigned int)(nbuckets * sizeof(struct sym_entry *)));
   rv->nBuckets = nbuckets;
   rv->nEntries = 0;
   return rv;
   }

/*
 * delete_st - destruct symbol table.
 */
void delete_st(SymbolTable st)
   {
   SymbolTableEntry se, se1;
   int h;
   for (h = 0; h < st->nBuckets; ++h)
      for (se = st->tbl[h]; se != NULL; se = se1) {
		  if(se->table != NULL){
	 			delete_st(se->table);
	 		}
         se1 = se->next;
	 	 free((char *)se->s); /* strings in the table were all strdup'ed. */
         free((char *)se);
    }
   free((char *)st->tbl);
   free((char *)st);
   }

/*
 * Compute hash value.
 */
int hash(SymbolTable st, char *s)
{
   register int h = 0;
   register char c;
   while ((c = *s++)) {
      h += c & 0377;
      h *= 37;
      }
   if (h < 0) h = -h;
   return h % st->nBuckets;
}

/*
 * Insert a symbol into a symbol table.
 */
int insert_sym(SymbolTable st, char *s)// typeptr t, ask about this third argument
{
   //register int i;
   int h;
   struct sym_entry *se;
   //int l;
   h = hash(st, s);
   for (se = st->tbl[h]; se != NULL; se = se->next)
      if (!strcmp(s, se->s)) {
         return 0;
         }

   /*
    * The string is not in the table. Add the copy from the
    *  buffer to the table.
    */
   se = (SymbolTableEntry)alloc((unsigned int) sizeof (struct sym_entry));
   se->next = st->tbl[h];
   se->table = NULL;
   st->tbl[h] = se;
   se->s = strdup(s);
   //se->type = t;
   st->nEntries++;
   return 1;
}

/*
 * lookup_st - search the symbol table for a given symbol, return its entry.
 */
SymbolTableEntry lookup_st(SymbolTable st, char *s)
   {
   //register int i;
   int h;
   SymbolTableEntry se;

   h = hash(st, s);
   for (se = st->tbl[h]; se != NULL; se = se->next)
      if (!strcmp(s, se->s)) {
         return se;
         }
   return NULL;
   }



char * alloc(int n)
{
   char *a = calloc(n, sizeof(char));
   if (a == NULL) {
      fprintf(stderr, "alloc(%d): out of memory\n", (int)n);
      exit(-1);
      }
   return a;
}

void enter_newscope(char *s)
{
   /* allocate a new symbol table */
   SymbolTable table = new_st(SYMTAB_SIZE);
   /* insert s into current symbol table */
   insert_sym(current, s);
   /* attach new symbol table to s's symbol table in the current symbol table*/
	//Work on this
	//table = lookup_st(current, s)->table;
	lookup_st(current, s)->table = table;

   /* push new symbol on the stack, making it the current symbol table */
   pushscope(table);
}

void populate_symboltables(struct tree * n)
{
   int i;
   if (n == NULL) return;
   //printf("%s\n", n->symbolname);
   /* pre-order activity */
  // printf("%s\n", n->symbolname);
  //popscope to escape
   switch (n->prodrule) {
   case 1090: case 1091: {  /* MethodDeclarator whatever production rule(s) enter a function scope */
	 redeclaration_error(current, n->kids[0]);
	 method_count++;
	 enter_newscope(n->kids[0]->symbolname);
     break;
     }
	case 1110: { //formal param
		redeclaration_error(current, n->kids[1]);
		insert_sym(current, n->kids[1]->symbolname);
		break;
	}
	case 1111: {// formal param array
		redeclaration_error(current, n->kids[1]);
		insert_sym(current, n->kids[1]->symbolname);
		break;
	}
   case 1000: {  /* ClassDecl whatever production rule(s) enter a function scope */
     enter_newscope(n->kids[0]->symbolname);
     break;
     }
   case 1240: case 1250:  { //WhileStmt ForStmt whatever production rule(s) enter a struct scope
	 block_count++;
  	 /*if(block_count > 1)
  	 	popscope();*/
	char* temp = (char*) alloc(sizeof(char) * BUFF);
	sprintf(temp, "%s%d", n->symbolname, block_count);
	n->symbolname = realloc(n->symbolname, strlen(temp) * BUFF);
	strcpy(n->symbolname, temp);
    enter_newscope(n->symbolname);
	free(temp);
     break;
 		} /* label of new struct  inside enter new scope*/
	case 1241:{//empty while statement
		block_count++;
     	 /*if(block_count > 1)
     	 	popscope();*/
   		char* temp = (char*) alloc(sizeof(char) * BUFF);
   		sprintf(temp, "%s%d", n->symbolname, block_count);
   		n->symbolname = realloc(n->symbolname, strlen(temp) * BUFF);
   		strcpy(n->symbolname, temp);
        insert_sym(current, n->symbolname);
		free(temp);
        break;
	}
   case 1030: case 1031: case 1170: { /* "FieldDecl", "LocalVarDecl" whatever production rule(s) designate a variable declaration*/
       /* figure out which kid is a "list" of variables */
	   /*Check */
	   if(n->kids[0]->prodrule == 1050){
		   dovariabledeclarator(n->kids[1]);
	   }else{
		    redeclaration_error(current, n->kids[1]);
		   	insert_sym(current, n->kids[1]->symbolname);
	   }
       /* walk through the subtree that is the list of variables */
            /* for each variable, insert it into the current symbol table*/
       break;
   	}
	case 1171: case 1172:{//more local var decls
		redeclaration_error(current, n->kids[1]);
		insert_sym(current, n->kids[1]->symbolname);
		break;
	}
	case 1173: case 1174:{//local var array decls
		redeclaration_error(current, n->kids[1]);
		insert_sym(current, n->kids[1]->symbolname);
		break;
	}
   }

   for (i=0; i<n->nkids; i++){
      populate_symboltables(n->kids[i]);
  }

	  /* post-order activity*/
    switch (n->prodrule) {
		case 1240: case 1250: {//while statment and for statement
			popscope();
			break;
		}
		case 1070: { //method decl
			if(method_count >= 1){
				popscope();
			}
			break;
		}
		case 1180:{ //ExprStmt
			//printf("%d\n", n->kids[0]->kids[0]->prodrule);
			switch(n->kids[0]->prodrule){
				case 1390: {
					if(n->kids[0]->kids[0]->prodrule == 270){
					if(not_defined_error(current, n->kids[0]->kids[0]) == 0){//LeftHandSide
					  fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[0]->symbolname, n->kids[0]->kids[0]->leaf->lineno);
				  	   semanticerror("Variable not declared error", n->kids[0]->kids[0]);
					   exit(3);
						}
					}else if(n->kids[0]->kids[0]->prodrule == 1430){
						if(not_defined_error(current, n->kids[0]->kids[0]->kids[0]) == 0){//LeftHandSide
						  fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[0]->kids[0]->symbolname, n->kids[0]->kids[0]->kids[0]->leaf->lineno);
					  	   semanticerror("Variable not declared error", n->kids[0]->kids[0]->kids[0]);
						   exit(3);
							}
					}
					if(not_defined_error(current, n->kids[0]->kids[2]) == 0 && n->kids[0]->kids[2]->prodrule == IDENTIFIER){
						fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[2]->symbolname, n->kids[0]->kids[2]->leaf->lineno);
						semanticerror("Variable not declared error", n->kids[0]->kids[2]);
						exit(3);
					}else if(n->kids[0]->kids[2]->prodrule == 1340){//AddExpr
						for(int i = 0; i < n->kids[0]->kids[2]->nkids; i++){
							if(not_defined_error(current, n->kids[0]->kids[2]->kids[i]) == 0 && n->kids[0]->kids[2]->kids[i]->prodrule == IDENTIFIER){
								fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[2]->kids[i]->symbolname, n->kids[0]->kids[2]->kids[i]->leaf->lineno);
								semanticerror("Variable not declared error", n->kids[0]->kids[2]);
								exit(3);
							}
						}
					}
					break;
				}
				case 1391: case 1392:{ //Assignment Expressions
					if(not_defined_error(current, n->kids[0]->kids[0]) == 0){//LeftHandSide
					  fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[0]->symbolname, n->kids[0]->kids[0]->leaf->lineno);
				  	   semanticerror("Variable not declared error", n->kids[0]->kids[0]);
					   exit(3);
					}
					break;
				}
				case 1310: case 1311: case 1314:{//MethodCall
					if(n->kids[0]->kids[0]->prodrule != 1040 && not_defined_error(current, n->kids[0]->kids[0]) == 0){//QualifiedName
						fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[0]->symbolname, n->kids[0]->kids[0]->leaf->lineno);
   				  	   semanticerror("Variable not declared error", n->kids[0]->kids[0]);
   					   exit(3);
				   }else if(n->kids[0]->kids[0]->prodrule == 1040)
				   		qualified_name(current, n->kids[0]->kids[0]);
					if(n->kids[0]->nkids > 1){
						if(not_defined_error(current, n->kids[0]->kids[1]) == 0){
							fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[1]->symbolname, n->kids[0]->kids[1]->leaf->lineno);
		    				semanticerror("Variable not declared error", n->kids[0]->kids[1]);
		    				exit(3);
							}
						}
					break;
				}
				case 1312: case 1313:{//still MethodCall
					if(not_defined_error(current, n->kids[0]->kids[0]) == 0){
					   fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[0]->symbolname, n->kids[0]->kids[0]->leaf->lineno);
   				  	   semanticerror("Variable not declared error", n->kids[0]->kids[0]);
   					   exit(3);
					}
					if(not_defined_error(current, n->kids[0]->kids[1]) == 0){
						fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[0]->symbolname, n->kids[0]->kids[0]->leaf->lineno);
    				  	   semanticerror("Variable not declared error", n->kids[0]->kids[0]);
    					   exit(3);
					}
					if(n->kids[0]->nkids > 2){
						if(not_defined_error(current, n->kids[0]->kids[2]) == 0){
							fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->kids[0]->symbolname, n->kids[0]->kids[0]->leaf->lineno);
	    				  	   semanticerror("Variable not declared error", n->kids[0]->kids[0]);
	    					   exit(3);
						}
					}
					break;
				}


			}
			break;
		}
		case 1401:{
			if(not_defined_error(current, n->kids[1]) == 0){
				fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
				   semanticerror("Variable not declared error", n->kids[1]);
				   exit(3);
			}
			break;
		}
		case 1402:{
			if(not_defined_error(current, n->kids[1]) == 0){
				fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[1]->symbolname, n->kids[1]->leaf->lineno);
				   semanticerror("Variable not declared error", n->kids[1]);
				   exit(3);
			}
			break;
		}
		case 1403:{
			if(not_defined_error(current, n->kids[0]) == 0){
				fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->symbolname, n->kids[0]->leaf->lineno);
				   semanticerror("Variable not declared error", n->kids[0]);
				   exit(3);
			}
			break;
		}
		case 1404:{
			if(not_defined_error(current, n->kids[0]) == 0){
				fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->symbolname, n->kids[0]->leaf->lineno);
				   semanticerror("Variable not declared error", n->kids[0]);
				   exit(3);
			}
			break;
		}
		case 1405:{
			if(not_defined_error(current, n->kids[0]) == 0){
				fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[0]->symbolname, n->kids[0]->leaf->lineno);
				   semanticerror("Variable not declared error", n->kids[0]);
				   exit(3);
			}
			break;
		}

	}
   	/*case 1090: case 1240: case 1250:// MethodDecl we are back out to a node where we entered a subscope :
		printf("bark\n");
        popscope();
        break;
   	case 1091:
   		if(strcmp(n->kids[0]->symbolname, "main") != 0){
			printf("bark\n");
			popscope();
		}
   	break;
}*/
}

void dovariabledeclarator(struct tree * n)
{
  /* in future look for type information (e.g. array, pointer) modifiers */
  /* get variable ident */
	for(int i = 0; i<n->nkids; i++){
		if(n->kids[i]->prodrule == IDENTIFIER){
			redeclaration_error(current, n);
			insert_sym(current, n->kids[i]->symbolname);
		}
	}
}

int redeclaration_error(SymbolTable st, struct tree * n){
	if(lookup_st(st, n->symbolname)!= NULL){
	   fprintf(stderr, "Redeclaration error for %s at line %d ",n->symbolname, n->leaf->lineno);
 	   semanticerror("Redeclaration error", n);
 	   exit(3);
	}
	if(st->parent != NULL){
		return redeclaration_error(st->parent, n);
	}else{
		return 0;
	}
}

int qualified_name(SymbolTable st, struct tree * n){
	for(int i = 0; i < n->nkids; i++){
		if(n->kids[i]->prodrule == 1040){
			return qualified_name(st, n->kids[i]);
		}else{
			if(not_defined_error(st, n->kids[i]) == 0){
				fprintf(stderr, "Variable not declared error for %s at line %d ",n->kids[i]->symbolname, n->kids[i]->leaf->lineno);
				semanticerror("Variable not declared error", n->kids[i]);
				exit(3);
			}
		}
	}
	return 0;
}

int not_defined_error(SymbolTable st, struct tree * n){
	if(lookup_st(st, n->symbolname)!= NULL){
	   return 1;
	}
	if(st->parent != NULL){
		return not_defined_error(st->parent, n);
	}else{
		return 0;
	}
}

void printsymbols(SymbolTable st, int level)
{
   int i;//, j;
   SymbolTableEntry ste;
   if (st == NULL) return;
   for (i=0;i<st->nBuckets;i++) {
      for (ste = st->tbl[i]; ste; ste=ste->next) {
	// for (j=0; j < level; j++) printf("\t");
	 printf("%s\n", ste->s);
	 /* if this symbol has a subscope, print it recursively, indented
	 printsymbols( // subscope symbol table
                    , level+1);
          */
      }
   }
	printf("---------------------------------------\n");
   for (i=0;i<st->nBuckets;i++) {
      for (ste = st->tbl[i]; ste; ste=ste->next) {
		  if(ste->table != NULL){
			  printf("----------symbol table for %s----------\n", ste->s);
	 			printsymbols(ste->table, level+1);
	 		}
	  }
  }
}

void semanticerror(char *s, struct tree * n)
{
   while (n && (n->nkids > 0))
   		n=n->kids[0];
   if (n) {
     fprintf(stderr, "%s:%d: ", n->leaf->filename, n->leaf->lineno);
   }
  fprintf(stderr, "%s", s);
  if (n && n->prodrule == IDENTIFIER)
  	fprintf(stderr, " %s", n->leaf->text);
  fprintf(stderr, "\n");
  //errors++;
}

SymbolTable buildglobal(SymbolTable glob){
	glob = new_st(SYMTAB_SIZE);
	current = new_st(SYMTAB_SIZE);
	glob->parent = NULL;
	insert_sym(glob, "System");
	insert_sym(glob, "String");
	lookup_st(glob, "System")->table = new_st(SYMTAB_SIZE);
	lookup_st(glob, "String")->table = new_st(SYMTAB_SIZE);
	insert_sym(lookup_st(glob, "System")->table, "out");
	insert_sym(lookup_st(glob, "System")->table, "in");
	insert_sym(lookup_st(glob, "String")->table, "charAt");
	insert_sym(lookup_st(glob, "String")->table, "equals");
	insert_sym(lookup_st(glob, "String")->table, "compareTo");
	insert_sym(lookup_st(glob, "String")->table, "length");
	insert_sym(lookup_st(glob, "String")->table, "toString");
	lookup_st(lookup_st(glob, "System")->table, "out")->table = new_st(SYMTAB_SIZE);
	lookup_st(lookup_st(glob, "System")->table, "in")->table = new_st(SYMTAB_SIZE);
	insert_sym(lookup_st(lookup_st(glob, "System")->table, "out")->table, "print");
	insert_sym(lookup_st(lookup_st(glob, "System")->table, "out")->table, "println");
	insert_sym(lookup_st(lookup_st(glob, "System")->table, "in")->table, "read");
	pushscope(glob);
	return glob;
}
