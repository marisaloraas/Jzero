public class HelloWorld{
  int a;
  public static void main(String[] args){
    a = 5;
	while(true){
		System.out.println("Stuff");
	}
	for(i = 0; i < a; i++){
		System.out.println("Hellow Worlds");
	}
  }
}
