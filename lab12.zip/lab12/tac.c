/*
 * Three Address Code - skeleton for CS 423
 */
#include <stdio.h>
#include <stdlib.h>
#include "tac.h"
#include "tree.h"

char *regionnames[] = {"global","loc", "class", "lab", "const", "", "none"};
char *regionname(int i) { return regionnames[i-R_GLOBAL]; }
char *opcodenames[] = {
   "ADD","SUB", "MUL", "DIV", "NEG", "ASN", "ADDR", "LCONT", "SCONT", "GOTO",
   "BLT", "BLE", "BGT", "BGE", "BEQ", "BNE", "BIF", "BNIF", "PARM", "CALL",
   "RETURN"
   };
char *opcodename(int i) { return opcodenames[i-O_ADD]; }
char *pseudonames[] = {
   "glob","proc", "loc", "lab", "end", "prot"
   };
char *pseudoname(int i) { return pseudonames[i-D_GLOB]; }

int labelcounter;

struct addr *genlabel()
{
   struct addr *a = malloc(sizeof(struct addr));
   a->region = R_LABEL;
   a->u.offset = labelcounter++;
   printf("generated a label %d\n", a->u.offset);
   return a;
}

struct instr *gen(int op, struct addr a1, struct addr a2, struct addr a3)
{
  struct instr *rv = malloc(sizeof (struct instr));
  if (rv == NULL) {
     fprintf(stderr, "out of memory\n");
     exit(4);
     }
  rv->opcode = op;
  rv->dest = a1;
  rv->src1 = a2;
  rv->src2 = a3;
  rv->next = NULL;
  return rv;
}

struct instr *copylist(struct instr *l)
{
   if (l == NULL) return NULL;
   struct instr *lcopy = gen(l->opcode, l->dest, l->src1, l->src2);
   lcopy->next = copylist(l->next);
   return lcopy;
}

struct instr *append(struct instr *l1, struct instr *l2)
{
   if (l1 == NULL) return l2;
   struct instr *ltmp = l1;
   while(ltmp->next != NULL) ltmp = ltmp->next;
   ltmp->next = l2;
   return l1;
}

struct instr *concat(struct instr *l1, struct instr *l2)
{
   return append(copylist(l1), l2);
}

void assign_first(struct tree *t)
{  int i;
   for(i=0; i<t->nkids; i++) assign_first(t->kids[i]);
   switch(t->prodrule) {
     	case 1320: case 1321: case 1322: {//UnaryExpr
			if(t->kids[1]->first == NULL){
				t->first = genlabel();
			}else{
				t->first = t->kids[1]->first;
			}
			break;
		}
		case 1340: case 1341:{//AddExpr
			if(t->kids[0]->first != NULL){
				t->first = t->kids[0]->first;
			}else if(t->kids[1]->first != NULL){
				t->first = t->kids[1]->first;
			}else{
				t->first = genlabel();
			}
			break;
		}
		case 1330: case 1331: case 1332:{ //MulExpr
			if(t->kids[0]->first != NULL){
				t->first = t->kids[0]->first;
			}else if(t->kids[1]->first != NULL){
				t->first = t->kids[1]->first;
			}else{
				t->first = genlabel();
			}
			break;
		}
		case 1350:{ //RelExpr
			if(t->kids[0]->first != NULL){
				t->first = t->kids[0]->first;
			}else if(t->kids[2]->first != NULL){
				t->first = t->kids[2]->first;
			}else{
				t->first = genlabel();
			}
			break;
		}
		case 1140: case 1240: case 1241:{//Block WhileStmt
			if(t->kids[0]->first != NULL){
				t->first = t->kids[0]->first;
			}else{
				t->first = genlabel();
			}
			break;
		}
		case 1250: case 1251: case 1252:{//ForStmt
			if(t->kids[0]->first != NULL){
				t->first = t->kids[0]->first;
			}else{
				t->first = genlabel();
			}
			break;
		}
		case 1150:{//Block Stmts
			if(t->kids[0]->first == NULL){
				t->kids[0]->first = genlabel();
			}else if(t->kids[1]->first != NULL){
				t->first = t->kids[1]->first;
			}else{
				t->first = t->kids[0]->first;
			}
			break;
		}
		default:{
			if(t->nkids != 0){
				for(int i = 0; i < t->nkids; i++){
					if(t->kids[i]->first != NULL){
						t->first = t->kids[i]->first;
					}
				}
			}
			break;
		}
   }
}

void assign_follow(struct tree *t){
	switch(t->prodrule){
		case 1070:{//MethodDecl
			break;
		}
		case 1150:{//BlockStmts
			break;
		}
		case 1140:{//Block
			break;
		}
	}
}
