public class foo {
   public static void main()
   {
   int i;
   i = 0;
   while (i < 20) {
      i = i * i + 1;
      }
   System.out.println(i);
   }
}
