/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BAD_TOKEN = 258,
     DOUBLE = 259,
     ELSE = 260,
     FOR = 261,
     IF = 262,
     INT = 263,
     RETURN = 264,
     VOID = 265,
     WHILE = 266,
     CHAR = 267,
     FLOAT = 268,
     LONG = 269,
     IDENTIFIER = 270,
     CLASSNAME = 271,
     CLASS = 272,
     STRING = 273,
     BOOL = 274,
     INTLIT = 275,
     DOUBLELIT = 276,
     CHARLIT = 277,
     STRINGLIT = 278,
     BOOLLIT = 279,
     NULLVAL = 280,
     LESSTHANOREQUAL = 281,
     GREATERTHANOREQUAL = 282,
     ISEQUALTO = 283,
     NOTEQUALTO = 284,
     LOGICALAND = 285,
     LOGICALOR = 286,
     LOGICNOT = 287,
     GREATERTHAN = 288,
     LESSTHAN = 289,
     MODULO = 290,
     MULT = 291,
     DIVIDE = 292,
     ADD = 293,
     SUBTRACT = 294,
     PERIOD = 295,
     LPAREN = 296,
     RPAREN = 297,
     LSQUARE = 298,
     RSQUARE = 299,
     LCURLY = 300,
     RCURLY = 301,
     COMMA = 302,
     SEMICOLON = 303,
     ASSIGNMENT = 304,
     COLON = 305,
     INCREMENT = 306,
     DECREMENT = 307,
     PUBLIC = 308,
     STATIC = 309,
     PRINT = 310,
     NEW = 311
   };
#endif
/* Tokens.  */
#define BAD_TOKEN 258
#define DOUBLE 259
#define ELSE 260
#define FOR 261
#define IF 262
#define INT 263
#define RETURN 264
#define VOID 265
#define WHILE 266
#define CHAR 267
#define FLOAT 268
#define LONG 269
#define IDENTIFIER 270
#define CLASSNAME 271
#define CLASS 272
#define STRING 273
#define BOOL 274
#define INTLIT 275
#define DOUBLELIT 276
#define CHARLIT 277
#define STRINGLIT 278
#define BOOLLIT 279
#define NULLVAL 280
#define LESSTHANOREQUAL 281
#define GREATERTHANOREQUAL 282
#define ISEQUALTO 283
#define NOTEQUALTO 284
#define LOGICALAND 285
#define LOGICALOR 286
#define LOGICNOT 287
#define GREATERTHAN 288
#define LESSTHAN 289
#define MODULO 290
#define MULT 291
#define DIVIDE 292
#define ADD 293
#define SUBTRACT 294
#define PERIOD 295
#define LPAREN 296
#define RPAREN 297
#define LSQUARE 298
#define RSQUARE 299
#define LCURLY 300
#define RCURLY 301
#define COMMA 302
#define SEMICOLON 303
#define ASSIGNMENT 304
#define COLON 305
#define INCREMENT 306
#define DECREMENT 307
#define PUBLIC 308
#define STATIC 309
#define PRINT 310
#define NEW 311




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 10 "j0gram.y"
{
   struct tree *treeptr;
}
/* Line 1529 of yacc.c.  */
#line 165 "j0gram.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

