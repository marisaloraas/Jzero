#include <stdio.h>
#include <stdlib.h>
extern FILE *yyin;
extern int yyparse(FILE *f);

int yyerror(char *s) {
   fprintf(stderr, "%s\n", s); exit(1);
}

int main(int argc, char *argv[]) {
    yyin = fopen(argv[1], "r");
    int out = yyparse(yyin);
    printf("yyparse returns %d\n", out);
	fclose(yyin);
}
