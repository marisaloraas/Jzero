/*
* @filename HW2.c
* @author Marisa Loraas
* @Date 2/8/22
* @breif Functions for hw2
*/
#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include "y.tab.h"

//function to check file extension name
char *filename(char *fname, int flength){
	if(strrchr(fname, '.') == NULL)
		strcat(fname, ".java");
	else if (strcmp(strrchr(fname, '.'), ".java") == 0)
		fname[flength] = '\0';
	else
    return "ERROR";
	return fname;
}

//frees tokenlist
void freelist(struct tokenlist *list) {
	struct tokenlist *temp;
	struct tokenlist *nextlist = list->next;
	while(nextlist != NULL) {
		//printf("freeing %s\n", nextlist->t->filename);
        temp = nextlist->next;
        free(nextlist->t->text);
        free(nextlist->t->filename);
        if(nextlist->t->category == 277)
            free(nextlist->t->sval);
        free(nextlist->t);
        free(nextlist);
        nextlist = temp;
    }
    free(list);
}

//add new token to token list
void addnewtoken(struct tokenlist *list, struct token *token) {
    struct tokenlist *temp = list;
    while(temp->next != NULL)
        temp = temp->next;
    temp->next = (struct tokenlist *)malloc(sizeof(struct tokenlist));
    temp->next->t = token;
}

//print token list
void print(struct tokenlist *list) {
    struct tokenlist *temp = list->next;
	printf("Category \t\t Text \t\t Lineno \t\t Filename\t\t Ival/Sval\t\t\n\n");
    for(temp = list->next; temp != NULL; temp = temp->next)  {
        printf("%d\t\t\t", temp->t->category);
        printf("%s\t\t\t", temp->t->text);
		printf("%d\t\t", temp->t->lineno);
        printf("%s\t\t", temp->t->filename);
        switch (temp->t->category) {
        case 275:
            printf("    %d\n", temp->t->ival);
            break;
        case 276:
            printf("    %f\n", temp->t->dval);
            break;
        case 277:
            printf("%s\n", temp->t->text);
			//printf("sendhelp\n");
			break;
        default:
            printf("\n");
			break;
        }
    }

}
