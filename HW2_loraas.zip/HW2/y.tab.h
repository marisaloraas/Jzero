/*
* @filename y.tab.h
* @author Marisa Loraas
* @Date 2/8/22
* @breif Header file for all token return code numbers, structers to tokens, and
* function headers in HW2.c
*/
#ifndef HEADER_FILE
#define HEADER_FILE
#include <stdio.h>

//structures
struct token {
   int category;   /* the integer code returned by yylex */
   char *text;     /* the actual string (lexeme) matched */
   int lineno;     /* the line number on which the token occurs */
   char *filename; /* the source file in which the token occurs */
   int ival;       /* for integer constants, store binary value here */
   double dval;	   /* for real constants, store binary value here */
   char *sval;     /* for string constants, malloc space, de-escape, store */
                   /*    the string (less quotes and after escapes) here */
   };

	struct tokenlist {
    struct token *t;
    struct tokenlist *next;
  };

//Reserved words, literals, and types
#define PUBLIC 258
#define DOUBLE 259
#define ELSE 260
#define FOR 261
#define IF 262
#define INT 263
#define RETURN 264
#define VOID 265
#define WHILE 266
#define IDENTIFIER 267
#define CLASSNAME 268
#define CLASS 269
#define STATIC 270
#define CHAR 271
#define FLOAT 272
#define STRING 273
#define BOOL 274
#define INTLIT 275
#define DOUBLELIT 276
#define STRINGLIT 277
#define BOOLLIT 278
#define LONG 279
#define NULLVAL 280

//Punctuation and operators
#define LESSTHANOREQUAL 298
#define GREATERTHANOREQUAL 300
#define ISEQUALTO 301
#define NOTEQUALTO 302
#define LOGICALAND 303
#define LOGICALOR 304
#define INCREMENT 306
#define DECREMENT 307
#define RPAREN 308
#define LPAREN 309
#define RSQUARE 310
#define LSQUARE 311
#define RCURLY 312
#define LCURLY 313
#define SEMICOLON 314
#define COLON 315
#define LOGICNOT 316
#define MULT 317
#define DIVIDE 318
#define MODULO 319
#define ADD 320
#define SUBTRACT 321
#define LESSTHAN 322
#define GREATERTHAN 323
#define ASSIGNMENT 324
#define COMMA 325
#define PERIOD 326

#define YYERRCODE 256

//function headers
char *filename(char *fname, int flength);
void freelist(struct tokenlist *list);
void addnewtoken(struct tokenlist *list, struct token *token);
void print(struct tokenlist *list);

#endif
