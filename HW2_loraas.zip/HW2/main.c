/*
* @filename main.c
* @author Marisa Loraas
* @Date 2/8/22
* @breif Main function for HW2
* @bugs Does not check lexical errors
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "y.tab.h"
extern FILE *yyin;
extern int yylex(void);
extern int yylex_destroy(void);
extern int rows;
extern char *yytext;

int main(int argc, char *argv[]) {
    int flength = strlen(argv[1]);
    char *fname = (char *)malloc(sizeof(char)*(flength+2));
	char* temp = filename(argv[1], flength);
	struct tokenlist *list = (struct tokenlist *)malloc(sizeof(struct tokenlist));
	int i = 0;
	if(strcmp(temp, "ERROR") == 0){
		printf("ERROR: Wrong File extension included");
		return -1;
	}else
		strcpy(fname, temp);
	yyin = fopen(fname, "r");
	// yylex loop
    while((i = yylex()) != -1) {
        struct token *tok = (struct token *)malloc(sizeof(struct token));
		tok->filename = (char *)malloc(sizeof(char) * flength);
		tok->lineno = rows;
		strncpy(tok->filename, fname, flength);
        switch (i) {
        	case 275:
            	tok->ival = atoi(yytext);
				//printf("ival: %d yytext: %d\n", tok->ival, atoi(yytext));
            	break;
        	case 276:
            	tok->dval = strtod(yytext, NULL);
            	break;
        	case 277:
            	tok->sval = (char *)malloc(sizeof(char) * strlen(yytext));
            	strcpy(tok->sval, yytext);
				break;
        	}

		tok->category = i;
		tok->text = (char *)malloc(sizeof(char) * strlen(yytext));
		strcpy(tok->text, yytext);
        addnewtoken(list, tok);
    }
	print(list);
	free(fname);
	fclose(yyin);
	freelist(list);
	yylex_destroy();
	return 0;
}
